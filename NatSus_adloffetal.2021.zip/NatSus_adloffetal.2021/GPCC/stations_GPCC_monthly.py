#! /usr/lib/python2.7
# -*- coding: utf-8 -*-

import time
import sys
from netCDF4 import Dataset
from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
from matplotlib import cm
from PIL import Image
from scipy.stats import ttest_ind,t
import scipy.stats as st
import numpy as np
import csv
import mkt

### 		  ###
#   General input   #
		    #
startyear = 1901    #
endyear = 2013	    #
region = 'yes'	    #
		    #
###		  ###


#read in netcdf files and create data lists ###

read_file='GPCC_mar_stations.nc'
#read_file='GPCC_annual_stations.nc'

data = Dataset(read_file, 'r')
print data.variables
lons = data.variables['lon'][:]
lats = data.variables['lat'][:]
station_map = data.variables['numgauge'][:,:,:] #time,lat,lon

years = np.arange(startyear,endyear+1)

### find lon and lat ###

if region == 'yes':
	for i in range(len(lons)-1):
		if lons[i] <= 33 and lons[i+1] > 33:
			lonmin = i
		elif lons[i] <= 54. and lons[i+1] > 54.:
			lonmax = i
	for i in range(len(lats)-1):
		if lats[i+1] <= -10. and lats[i] > -10.:
			latmin = i
		elif lats[i+1] <= 16. and lats[i] > 16. :
			latmax = i

else:
	lonmin,lonmax,latmin,latmax = 0,len(lons),len(lats),0

### create map of locations with persistent data throught measurement period ###
startyear = 1981
endyear = 2012

stations = [[0 for x in range(lonmin,lonmax)] for y in range(latmax,latmin)]
for lat in range(latmin-latmax):
	for lon in range(lonmax-lonmin):
		for t in range(startyear - 1901,endyear - 1901):
			if float(station_map[t][latmax+lat][lonmin+lon]) > 0.:
				stations[lat][lon] = stations[lat][lon]+1.
		if stations[lat][lon] >= endyear-startyear-5:
			stations[lat][lon] = 1
		else:
			stations[lat][lon] = np.nan
			
masked_stations=np.ma.masked_invalid(stations)

### plot ###

def plot_2D(data,lon,lat):

	fig = plt.figure(figsize=(5,7))
	m = Basemap(projection='merc', lat_0=0, lon_0=0,\
	    urcrnrlat=lat[0],llcrnrlat=lat[len(lat)-1],\
            llcrnrlon=lon[0],urcrnrlon=lon[len(lon)-1],resolution='l')
	# add rectangle
	xs = [33,33,53,53,33,53,33,53]
	ys = [-10,8,-10,8,-10,-10,8,8]

	x_mesh,y_mesh = np.meshgrid(lon,lat,indexing='ij')
	x,y = m(x_mesh,y_mesh)
	v,w = m(33,0)
	m.drawcountries()
	m.drawcoastlines()
	m.shadedrelief()
	p1 = m.pcolormesh(x,y,data,cmap=cm.Greys,vmin=0,vmax=5)
	cb = plt.colorbar(p1)
#	m.drawgreatcircle(33,-9.1,33,8,lw=3,c='teal')
#	m.drawgreatcircle(33,8,53.2,8,lw=3,c='teal')
#	m.drawgreatcircle(53.2,8,53.2,-9.1,lw=3,c='teal')
#	m.drawgreatcircle(53.2,-9.1,33,-9.1,lw=3,c='teal')
#	cb.ax.set_yticklabels(cb.ax.get_yticklabels(),rotation=90)
	cb.set_label(label = 'average station density 1983-2013',fontsize=18)
#	m.set_ylim([lon[0],lon[len(lon)-1]])
#	m.set_xlim([lat[0],lat[len(lat)-1]])
#	m.set_xlabel('lat', fontsize=18)
#	plt.setp( m.yaxis.get_majorticklabels(), rotation=90 )
#	m.set_ylabel('lon', fontsize=18)
#	plt.setp( m.xaxis.get_majorticklabels(), rotation=90 )

	plt.show()
#	filename="trends_1981-"+str(endyear)+"_annualprec_CRU"+str(startyear)+".png"
#	plt.savefig(filename)

def writing_to_netcdf(data_to_write,filename,lon,lat):

	write_file='GPCC_stations_'+filename+'_19812012.nc'

	dataset = Dataset(write_file, 'w',format='NETCDF3_CLASSIC')
	lo = dataset.createDimension('lon', len(lon)) 
	la = dataset.createDimension('lat', len(lat))
	tim = dataset.createDimension('time', 1)

	longitudes = dataset.createVariable('lon', np.dtype('float32'), ('lon',))
	latitudes = dataset.createVariable('lat', np.dtype('float32'), ('lat',))
	times = dataset.createVariable('time', np.dtype('float32'), ('time',))
	the_data = dataset.createVariable('prec', np.dtype('float32'), ('lat','lon'), fill_value = -9999) 
	
	longitudes[:] = lon
	latitudes[:] = lat
	times[0] = 1.
	the_data[:,:] = data_to_write

	longitudes.units = 'degrees_east'
	latitudes.units = 'degrees_north'
	times.units = 'year+dekade'
	the_data.units = 'mm'

	dataset.history = 'Created ' + time.ctime(time.time())

	dataset.close()

#plot_2D(np.swapaxes(masked_stations,0,1),lons[lonmin:lonmax],lats[latmax:latmin])
#plot_2D(np.swapaxes(masked_stations,0,1),lons[lonmin:lonmax],lats[latmax:latmin])
#station_map[station_map < 0.1] = np.nan
#station_map2 = np.ma.masked_invalid(station_map[0])
#plot_2D(np.swapaxes(station_map2[latmax:latmin,lonmin:lonmax],0,1),lons[lonmin:lonmax],lats[latmax:latmin])

writing_to_netcdf(masked_stations,'March_5',lons[lonmin:lonmax],lats[latmax:latmin])
