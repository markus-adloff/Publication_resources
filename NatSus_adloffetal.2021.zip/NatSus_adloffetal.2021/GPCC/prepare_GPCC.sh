#!/bin/bash -l

#Create one file of annual precipitation

#cdo yearsum X2001_630_e4_4220_364a_8a39_b4b6_88e2.175.10.6.27.nc GPCC_annual.nc

#cdo yearsum -selmon,3/6 X2001_630_e4_4220_364a_8a39_b4b6_88e2.175.10.6.27.nc GPCC_longrains.nc
#cdo yearsum -selmon,10/12 X2001_630_e4_4220_364a_8a39_b4b6_88e2.175.10.6.27.nc GPCC_OND.nc
#cdo yearsum -selmon,3/5 X2001_630_e4_4220_364a_8a39_b4b6_88e2.175.10.6.27.nc GPCC_MAM.nc

#cdo -selmon,3 X2001_630_e4_4220_364a_8a39_b4b6_88e2.175.10.6.27.nc GPCC_mar.nc
#cdo -selmon,4 X2001_630_e4_4220_364a_8a39_b4b6_88e2.175.10.6.27.nc GPCC_apr.nc
#cdo -selmon,5 X2001_630_e4_4220_364a_8a39_b4b6_88e2.175.10.6.27.nc GPCC_may.nc
#cdo -selmon,10 X2001_630_e4_4220_364a_8a39_b4b6_88e2.175.10.6.27.nc GPCC_oct.nc
#cdo -selmon,11 X2001_630_e4_4220_364a_8a39_b4b6_88e2.175.10.6.27.nc GPCC_nov.nc

#cdo -selmon,3 -selvar,precip full_data_monthly_v2018_05.nc GPCC_mar.nc
#cdo -selmon,4 -selvar,precip full_data_monthly_v2018_05.nc GPCC_apr.nc
#cdo -selmon,5 -selvar,precip full_data_monthly_v2018_05.nc GPCC_may.nc
#cdo -selmon,10 -selvar,precip full_data_monthly_v2018_05.nc GPCC_oct.nc
#cdo -selmon,11 -selvar,precip full_data_monthly_v2018_05.nc GPCC_nov.nc
#cdo -selmon,12 -selvar,precip full_data_monthly_v2018_05.nc GPCC_dec.nc

cdo yearsum full_data_monthly_v2018_05.nc GPCC_annual.nc
cdo yearsum -selmon,10/12 full_data_monthly_v2018_05.nc GPCC_OND.nc
cdo yearsum -selmon,3/5 full_data_monthly_v2018_05.nc GPCC_MAM.nc

cdo remapcon2,../CHIRPS/GRACE_grid_05_EA.txt GPCC_annual.nc GPCC_annual_EA_05deg.nc
cdo remapcon2,../CHIRPS/GRACE_grid_05_EA.txt GPCC_MAM.nc GPCC_MAM_EA_05deg.nc
cdo remapcon2,../CHIRPS/GRACE_grid_05_EA.txt GPCC_OND.nc GPCC_OND_EA_05deg.nc






