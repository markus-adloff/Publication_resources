#! /usr/bin/env python3.5.2
# -*- coding: utf-8 -*-

from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import cm
from netCDF4 import Dataset
import numpy as np
import csv
from datetime import datetime, timedelta
from netCDF4 import num2date, date2num

def writing_to_netcdf(data_to_write,filename,lon,lat,timesteps):

	write_file=filename

	dataset = Dataset(write_file, 'w',format='NETCDF3_CLASSIC')
	lo = dataset.createDimension('lon', len(lon)) 
	la = dataset.createDimension('lat', len(lat))
	tim = dataset.createDimension('time', len(timesteps))

	longitudes = dataset.createVariable('lon', np.dtype('float32'), ('lon',))
	latitudes = dataset.createVariable('lat', np.dtype('float32'), ('lat',))
	times = dataset.createVariable('time', np.dtype('float32'), ('time',))
	times.units = 'hours since 2002-04-01'
	times.calendar = 'gregorian'
	the_data = dataset.createVariable('prec', np.dtype('float32'), ('time','lat','lon'), fill_value = np.nan) 
	
	longitudes[:] = lon
	latitudes[:] = lat
	times[:] = date2num(timesteps, units = times.units,calendar = times.calendar)
	the_data[:,:,:] = data_to_write

	longitudes.units = 'degrees_east'
	latitudes.units = 'degrees_north'
	the_data.units = 'mm'

#	dataset.history = 'Created ' +time.ctime(time.time())

	dataset.close()

#read_file = "/media/ulfo/KINGSTON/DREAD_Datasets/Time_year_month.txt" #raw_input("input file")
read_file = "Final_GRACE_data_txt/Time_GRACE.txt" #raw_input("input file")

#months = [np.nan for i in range(178)]
months = [np.nan for i in range(213)]

with open(read_file,'r') as f:
	read = csv.reader(f, delimiter='\t')

	for row in read:
		print row
		if row[0] == '2002':
			months[int(row[1])-4] = 1

		elif row[0] == '2003':
			months[8+int(row[1])] = 1
		else:
			months[20+(int(row[0])-2004)*12+int(row[1])] = 1
		

#read_file = "/media/ulfo/KINGSTON/DREAD_Datasets/GRACE_TWS.txt" #raw_input("input file")
read_file = "Final_GRACE_data_txt/Groundwater_DMDA.txt" #raw_input("input file")

#GRACE_data = [[[ np.nan for i in range(80)] for j in range(60)] for z in range(178)]
GRACE_data = [[[ np.nan for i in range(80)] for j in range(60)] for z in range(213)]

#print GRACE_data[1]

with open(read_file,'r') as f:
	read = csv.reader(f, delimiter='\t')
	j = 0

	for row in read:
		i = 0
		month = 0
		time = 0
		for col in range(len(row)):
			if col/80 == 0:
				i = col
			elif col/80 == month+1:
				if (col-1)/80 == month:
					for k in range(len(months[time+1:])):
						if np.isfinite(months[k+time+1]):
							time = time+1+k
							break
				month = month+1
			i = col-month*80
#			print col
#			print time

			GRACE_data[time][j][i] = row[col]

		j=j+1

#print GRACE_data[1]

## calculate annual GRACE

#for mon in range(len(GRACE_data)):
#	if mon == 9:
#		year = 0
#	elif isinstance((mon-9)/12.,int):
#		year = year+1
#		GRACE_yearly.append(sum(GRACE_data[(year-1)*12+9:(year)*12+9])/12.)



lats = [17.25-0.5*i for i in range(60)]
lons = [22.25+0.5*j for j in range(80)]

dates = []
year=2002
mon=4
#for n in range(178):
for n in range(213):
	if mon==13:
		year=year+1
		mon=1
	dates.append(datetime(year, mon, 1)) 
	mon=mon+1

writing_to_netcdf(GRACE_data,'Final_Groundwater_DMDA.nc',lons,lats,dates)

