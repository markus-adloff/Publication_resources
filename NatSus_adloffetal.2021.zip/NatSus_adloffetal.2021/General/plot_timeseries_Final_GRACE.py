#! /usr/lib/python2.7
# -*- coding: utf-8 -*-

import time
import sys
from netCDF4 import Dataset
from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib import cm
from PIL import Image
from scipy.stats import ttest_ind,t
import scipy.stats as st
import numpy as np
import csv
import mkt

read_file='GRACE/Final_GRACE_CSR_lsm_Hargeisa_JF_fldmean.nc'

data = Dataset(read_file, 'r')
#print data.variables
time_CSR = data.variables['time'][:]
prec_annual_CSR = data.variables['prec'][:,0,0] #time,lat,lon

read_file='GRACE/Final_GRACE_Mascon_Hargeisa_JF_fldmean.nc'

data = Dataset(read_file, 'r')
#print data.variables
time_Mascon = data.variables['time'][:]
prec_annual_Mascon = data.variables['prec'][:,0,0] #time,lat,lon

read_file='GRACE/Final_Groundwater_DMDA_lsm_Hargeisa_JF_fldmean.nc'

data = Dataset(read_file, 'r')
#print data.variables
time_DMDA = data.variables['time'][:]
prec_annual_DMDA = data.variables['prec'][:,0,0] #time,lat,lon

time_DMDA = [2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014]
time_CSR = [2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]
time_Mascon = [2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019]

time_DMDA_JF = [2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014]
time_CSR_JF = [2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]
time_Mascon_JF = [2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019]

def plot():

	fig = plt.figure()
	ax = fig.add_subplot(111)
	p1 = ax.scatter(time_CSR_JF, prec_annual_CSR, color='black')
	p2, = ax.plot(time_CSR_JF, prec_annual_CSR, color='black', label='CSR')
	p3 = ax.scatter(time_Mascon_JF, prec_annual_Mascon, color='green')
	p4, = ax.plot(time_Mascon_JF, prec_annual_Mascon, color='green', label='Mascon')
	p5 = ax.scatter(time_CSR_JF, prec_annual_DMDA, color='blue')
	p6, = ax.plot(time_CSR_JF, prec_annual_DMDA, color='blue', label='Groundwater')
	ax.set_xlabel('Year',fontsize=18)
	ax.set_ylabel('TWS/Groundwater anomaly (mm)',fontsize=18)
	ax.set_xticks([2002,2004,2006,2008,2010,2012,2014,2016,2018,2020])
	ax.grid()
	ax.legend(loc=2)

	plt.show()
#	plt.savefig(filename)

plot()
