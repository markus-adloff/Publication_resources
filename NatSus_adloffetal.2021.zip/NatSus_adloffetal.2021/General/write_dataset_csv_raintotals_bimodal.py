#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

from netCDF4 import Dataset
import numpy as np
import csv


### Read in nc-files and produce csv ###

months = ['OND','MAM']
#percentiles = ['0','u50','50','90','95','99']
#percentiles = ['0','99100']
percentiles = ['0','90','95','99']
years = np.arange(1981,2019)
offset = years[0]-1979

#e = open('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_meanprec_bimodal_OND.csv','w')
#entry = '"Rain rate percentile [%]","annual rainfall [mm]"'
#e.write("%s\n" % entry)

for month in range(len(months)):
	print month
	for percentile in range(len(percentiles)):

		#e = open('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_raintotals_'+months[month]+'_'+percentiles[percentile]+'.csv','w')
		#e = open('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_raintotals_'+months[month]+'_U99.csv','w')
		e = open('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_raintotals_'+months[month]+'_'+percentiles[percentile]+'_newbimodal.csv','w')
		entry = '"Year","Precipitation (mm)"'
		e.write("%s\n" % entry)

		#read_file='/media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/'+percentiles[percentile]+'/mswep_'+str(percentiles[percentile])+'_'+str(months[month])+'_lsm_bimodal.nc'
		#read_file='/media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_U99_'+str(months[month])+'_lsm_bimodal.nc'
		read_file='/media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_above_'+percentiles[percentile]+'pct_'+str(months[month])+'_newbimodal_africa.nc'

		data = Dataset(read_file, 'r')
		#print data.variables
		lons = data.variables['lon'][:]
		lats = data.variables['lat'][:]
		trends = data.variables['precipitation'][:,:,:] #lat,lon

		for lat in range(len(lats)): #lat, lon were inverted for R99 (for whatever reason...)
			for lon in range(len(lons)):
				for year in range(len(years)):
					if np.isnan(trends[year+offset][lat][lon]) != True and trends[year+offset][lat][lon] > 0: # was >= for R99
						entry = '"'+str(years[year])+'",'+str(trends[year+offset][lat][lon]) 
						e.write("%s\n" % entry)

		e.close()

	

