#! /usr/lib/python2.7
# -*- coding: utf-8 -*-

from netCDF4 import Dataset
import numpy as np
import csv

#readfiles = ['ECHAM','CAM4','MIROC5','NorESM']
#startyears = [1959,1979,1950,1959]
#readfiles = ['CRU','GPCC','CHIRPS','TAMSAT','ERA-Iterim','NCEP','CFSR','JRA-55']
#startyears = [1901,1901,1981,1983,1979,1979,1979,1958]
readfiles = ['CRU','GPCC','CHIRPS','MSWEP2','ARC2','ERA5']
startyears = [1901,1891,1981,1979,1983,1983]
#readfiles = ['ARC2','ERA5']
#startyears = [1983,1983]
#readfiles = ['TAMSAT',]
#startyears = [1984,]
#readfiles = ['GPCC',]
#startyears = [1901,]

month = 'MAM' #'OND'


for i in range(len(readfiles)):
#read in netcdf files and create data lists ###
	print readfiles[i]
	data = Dataset(readfiles[i]+'_'+month+'_timeseries_newbimodal.nc', 'r')
	#print data.variables
	prec_annual = data.variables['prec'][:,:,:] #time

	years = np.arange(startyears[i],startyears[i]+len(prec_annual))
	if readfiles[i] == 'TAMSAT':
		if month == 'nov':
			years = [1984,1988,1989,1991,1992,1993,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]
		if month == 'nov':
			years = [1984,1986,1988,1990,1991,1992,1996,1997,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]
		if month == 'nov':
			years = [1983,1984,1987,1988,1990,1992,1994,1995,1996,1997,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]
		if month == 'nov':
			years = [1984,1985,1986,1987,1988,1989,1990,1991,1992,1994,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]
		if month == 'nov':
			years = [1987,1990,1991,1992,1994,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]
		if month == 'MAM':
			years = [1984,1988,1992,1996,1997,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]
		if month == 'ON':
			years = [1987,1990,1991,1992,1994,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]
		if month == 'OND':
			years = [1987,1990,1991,1994,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017]

### write data file ###

	filename = month+'sum_EA_'+readfiles[i]+'newbimodal.csv'
	with open(filename,'w') as f:
		write=csv.writer(f,delimiter=',')
		for year in range(len(prec_annual)):
			write.writerow([years[year],prec_annual[year][0][0]])
