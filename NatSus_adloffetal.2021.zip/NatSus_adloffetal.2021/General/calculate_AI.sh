#!/bin/bash -l

for time in Sep #halfJanhalfFeb halfJunhalfJul halfJulhalfAug Jan Feb Jun Jul Aug
do

cdo sellonlatbox,37,52,-4.5,8 PET/${time}_pet_EA.nc PET/${time}_pet_EA_bimodal.nc
cdo fldmean PET/${time}_pet_EA_bimodal.nc PET/fldmean_${time}_pet_EA_bimodal.nc
cdo sellonlatbox,37,52,-4.5,8 CHIRPS/${time}_CHIRPS_EA_PET.nc CHIRPS/${time}_CHIRPS_EA_PET_bimodal.nc
cdo fldmean CHIRPS/${time}_CHIRPS_EA_PET_bimodal.nc CHIRPS/fldmean_${time}_CHIRPS_EA_bimodal.nc

done
