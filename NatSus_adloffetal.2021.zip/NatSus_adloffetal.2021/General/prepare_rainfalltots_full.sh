#!/bin/bash -l


for percent in 50 95 #0 9599 99100 #0 u50 50 90 95 99
do

#thresholds based on all rainfall
#cdo ifthen /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/0/mswep_8315_annualtots_lsm_2002.nc /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_OND.nc /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_OND_lsm.nc
#cdo ifthen /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/0/mswep_8315_annualtots_lsm_2002.nc /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_MAM.nc /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_MAM_lsm.nc
#cdo ifthen /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/0/mswep_8315_annualtots_lsm_2002.nc /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_annual.nc /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_annual_lsm.nc

#cdo sellonlatbox,37,54.25,-4.5,8 -setmisstoc,-1 /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_OND_lsm.nc /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_OND_lsm_bimodal.nc
#cdo sellonlatbox,37,54.25,-4.5,8 -setmisstoc,-1 /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_MAM_lsm.nc /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_MAM_lsm_bimodal.nc
#cdo sellonlatbox,37,54.25,-4.5,8 -setmisstoc,-1 /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_annual_lsm.nc /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/$percent/mswep_${percent}_annual_lsm_bimodal.nc

#thresholds based on rainy seasons only
cdo ifthen /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/0/mswep_8315_annualtots_lsm_2002.nc /media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_R${percent}_OND.nc /media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_R${percent}_OND_lsm.nc
cdo ifthen /media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/0/mswep_8315_annualtots_lsm_2002.nc /media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_R${percent}_MAM.nc /media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_R${percent}_MAM_lsm.nc

cdo sellonlatbox,37,54.25,-4.5,8 -setmisstoc,-1 /media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_R${percent}_OND_lsm.nc /media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_R${percent}_OND_lsm_bimodal.nc
cdo sellonlatbox,37,54.25,-4.5,8 -setmisstoc,-1 /media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_R${percent}_MAM_lsm.nc /media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_R${percent}_MAM_lsm_bimodal.nc

#cdo remapcon2,../../GRACE_grid_05_EA.txt $percent/mswep_$percent_OND.nc $percent/mswep_GRACE_$percent_OND.nc
#cdo remapcon2,../../GRACE_grid_05_EA.txt $percent/mswep_$percent_MAM.nc $percent/mswep_GRACE_$percent_MAM.nc
#cdo remapcon2,../../GRACE_grid_05_EA.txt $percent/mswep_$percent_annual.nc $percent/mswep_GRACE_$percent_annual.nc

done
