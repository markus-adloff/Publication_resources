#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib import cm
import numpy as np
import csv
import seaborn as sns
from netCDF4 import Dataset
from sklearn.linear_model import TheilSenRegressor


### Read in data ###
data = Dataset('Final_Groundwater_ESA_BM_fldmean_janfeb.nc', 'r')
#print data.variables
sm_janfeb = data.variables['prec'][:,:,:] #time

data = Dataset('Final_Groundwater_ESA_BM_fldmean_junaug.nc', 'r')
#print data.variables
sm_junaug = data.variables['prec'][:,:,:] #time

### Regression ###

reg_janfeb = TheilSenRegressor(random_state=0).fit(np.asarray([2003+i for i in range(17)]).reshape(-1,1),sm_janfeb[:17,0,0])
predict_y_janfeb=TheilSenRegressor.predict(reg_janfeb,np.asarray([2003+i for i in range(17)]).reshape(-1,1))

reg_junaug = TheilSenRegressor(random_state=0).fit(np.asarray([2003+i for i in range(17)]).reshape(-1,1),sm_junaug[:,0,0])
predict_y_junaug=TheilSenRegressor.predict(reg_junaug,np.asarray([2003+i for i in range(17)]).reshape(-1,1))

def plot_seaborn():

	fig = plt.figure(figsize=(10,7))
	ax = fig.add_subplot(111)

	p1 = ax.scatter([2003+i for i in range(18)],sm_janfeb[:,0,0],color='brown',label='Jan-Feb')
	ax.plot([2003+i for i in range(18)],sm_janfeb[:,0,0],color='brown')
	ax.plot([2003+i for i in range(17)],np.asarray(predict_y_janfeb)+0.008,linestyle=':',color='brown')
	plt.text(2012,0.198,'slope = '+str(round((predict_y_janfeb[16]-predict_y_janfeb[15])*100,1)/100.)+' m$^{3}$/m$^{2}$/yr',rotation = -19,color='brown')
	p2 = ax.scatter([2003+i for i in range(17)],sm_junaug[:,0,0],color='gold',label='Jun-Aug')
	ax.plot([2003+i for i in range(17)],sm_junaug[:,0,0],color='gold')
	ax.plot([2003+i for i in range(17)],np.asarray(predict_y_junaug)+0.008,linestyle=':',color='gold')
	plt.text(2013.4,0.225,'slope = '+str(round((predict_y_junaug[16]-predict_y_junaug[15])*100,1)/100.)+' m$^{3}$/m$^{2}$/yr',rotation = -10,color='gold')
	ax.set_xlabel('Year',fontsize=15)
	ax.set_ylabel('Water content of top 10 cm of soil (m$^3$/m$^2$)',fontsize=15)
	plt.legend(loc='best')
	ax.xaxis.set_major_locator(ticker.FixedLocator([2003+i for i in range(0,17,2)]))
	ax.xaxis.set_minor_locator(ticker.FixedLocator([2003+i for i in range(1,16,2)]))
	plt.savefig('ESA_soilmoisture.pdf')
#	plt.show()
	
plot_seaborn()

