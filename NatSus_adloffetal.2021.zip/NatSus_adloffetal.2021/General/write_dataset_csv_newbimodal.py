#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

from netCDF4 import Dataset
import numpy as np
import csv


### Read in nc-files and produce csv ###

#months = ['March','April','May','October','November','December']
months = ['MAM','OND']
datasets = ['GPCC','CRU','ARC2','CHIRPS','MSWEP','ERA5']
#datasets = ['GPCC','CRU','CHIRPS','MSWEP']

e = open('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_regridded_newbimodal_seasonal_MSWEP2.csv','w')
entry = '"Dataset","Month","Trends [mm/yr]"'
e.write("%s\n" % entry)

for month in months:
	trends_mon = []
	for dataset in datasets:
		dist = []
		if dataset == 'MSWEP':
			read_file='/media/ulfo/KINGSTON/DREAD_Datasets/'+dataset+'_monthly_'+month+'_regridded_19832016_newbimodal.nc'
		else:
			read_file='/media/ulfo/KINGSTON/DREAD_Datasets/'+dataset+'_monthly_'+month+'_regridded_19832014_newbimodal.nc'

		data = Dataset(read_file, 'r')
		#print data.variables
		lons = data.variables['lon'][:]
		lats = data.variables['lat'][:]
		trends = data.variables['prec'][:,:] #lat,lon
	
		for lon in range(len(lons)):
			for lat in range(len(lats)):
				if np.isnan(trends[lat][lon]) != True and trends[lat][lon] != 0:
					if lats[lat] > 12.5:
						if lons[lon] < 42.5:
							entry = '"'+dataset+'","'+month+'",'+str(trends[lat][lon]) 
							e.write("%s\n" % entry)
					else:
						entry = '"'+dataset+'","'+month+'",'+str(trends[lat][lon]) 
						e.write("%s\n" % entry)
e.close()

	

