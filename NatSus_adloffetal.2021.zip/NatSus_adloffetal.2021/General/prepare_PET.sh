#!/bin/bash -l

#for year in {1981..2019..1}
#do
#cdo -setyear,${year} -sellonlatbox,32,56,-11,18 ${year}_daily_pet.nc ${year}_daily_pet_EA.nc
#rm ${year}_daily_pet.nc

#cdo timsum -setyear,${year} -seltimestep,15/46/1 ${year}_daily_pet_EA.nc ${year}_halfJanhalfFeb_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,166/196/1 ${year}_daily_pet_EA.nc ${year}_halfJunhalfJul_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,196/227/1 ${year}_daily_pet_EA.nc ${year}_halfJulhalfAug_pet_EA.nc

#cdo timsum -setyear,${year} -seltimestep,1/31/1 ${year}_daily_pet_EA.nc ${year}_Jan_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,32/59/1 ${year}_daily_pet_EA.nc ${year}_Feb_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,60/90/1 ${year}_daily_pet_EA.nc ${year}_Mar_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,91/120/1 ${year}_daily_pet_EA.nc ${year}_Apr_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,121/151/1 ${year}_daily_pet_EA.nc ${year}_May_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,152/181/1 ${year}_daily_pet_EA.nc ${year}_Jun_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,182/212/1 ${year}_daily_pet_EA.nc ${year}_Jul_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,213/243/1 ${year}_daily_pet_EA.nc ${year}_Aug_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,244/273/1 ${year}_daily_pet_EA.nc ${year}_Sep_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,274/304/1 ${year}_daily_pet_EA.nc ${year}_Oct_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,305/334/1 ${year}_daily_pet_EA.nc ${year}_Nov_pet_EA.nc
#cdo timsum -setyear,${year} -seltimestep,335/365/1 ${year}_daily_pet_EA.nc ${year}_Dec_pet_EA.nc

#done

#cdo -mergetime ????_halfJanhalfFeb_pet_EA.nc halfJanhalfFeb_pet_EA.nc
#cdo -mergetime ????_halfJunhalfJul_pet_EA.nc halfJunhalfJul_pet_EA.nc
#cdo -mergetime ????_halfJulhalfAug_pet_EA.nc halfJulhalfAug_pet_EA.nc
#cdo -mergetime ????_Jan_pet_EA.nc Jan_pet_EA.nc
#cdo -mergetime ????_Feb_pet_EA.nc Feb_pet_EA.nc
#cdo -mergetime ????_Mar_pet_EA.nc Mar_pet_EA.nc
#cdo -mergetime ????_Apr_pet_EA.nc Apr_pet_EA.nc
#cdo -mergetime ????_May_pet_EA.nc May_pet_EA.nc
#cdo -mergetime ????_Jun_pet_EA.nc Jun_pet_EA.nc
#cdo -mergetime ????_Jul_pet_EA.nc Jul_pet_EA.nc
#cdo -mergetime ????_Aug_pet_EA.nc Aug_pet_EA.nc
#cdo -mergetime ????_Sep_pet_EA.nc Sep_pet_EA.nc
#cdo -mergetime ????_Oct_pet_EA.nc Oct_pet_EA.nc
#cdo -mergetime ????_Nov_pet_EA.nc Nov_pet_EA.nc
#cdo -mergetime ????_Dec_pet_EA.nc Dec_pet_EA.nc

for month in Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec
do

cdo ifthen mswepFJSmask_lec30_invertlat_EA.nc ${month}_pet_EA.nc ${month}_pet_EA_newbimodal.nc
cdo masklonlatbox,32,56,-11,12 ${month}_pet_EA_newbimodal.nc ${month}_pet_EA_newbimodal_nan.nc
cdo fldmean ${month}_pet_EA_newbimodal_nan.nc fldmean_${month}_pet_EA_newbimodal.nc

done

