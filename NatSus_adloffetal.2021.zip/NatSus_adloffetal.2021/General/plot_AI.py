#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import cm
import numpy as np
import csv
import seaborn as sns


### Read in csv file ###
Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/AI_newbimodal.csv') #AI_bimodal_fullmonths.csv

def plot_seaborn():

	fig = plt.figure(figsize=(10,7))
	ax = fig.add_subplot(111)

	sns.catplot(x="Month", y="Aridity Index", kind="box", color='silver', showfliers = False, data=Data)
#	sns.stripplot(x="Month", y="Aridity Index", alpha=0.3, color='black', data=Data)
	plt.axhline(0.05,0,1,color='black')
	plt.text(-0.4,0.055,'hyperarid')
	plt.axhline(0.2,0,1,color='black')
	plt.text(-0.4,0.205,'arid')
#	plt.savefig('boxen_monthly_trends_bimodal_19832014.pdf')
	plt.show()
	
plot_seaborn()

