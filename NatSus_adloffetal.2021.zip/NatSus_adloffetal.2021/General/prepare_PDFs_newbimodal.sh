#!/bin/bash -l

for dataset in MSWEP #GPCC CRU CHIRPS ARC2 ERA5 MSWEP2
do

for month in MAM OND March April May October November December
do 

cdo ifthen /media/ulfo/KINGSTON/DREAD_DATASETS/mswepFJSmask_lec30_05deg_africa_nan.nc /media/ulfo/KINGSTON/DREAD_DATASETS/${dataset}_monthly_${month}_regridded_19832016.nc /media/ulfo/KINGSTON/DREAD_DATASETS/${dataset}_monthly_${month}_regridded_19832016_newbimodal.nc
#cdo ifthen /media/ulfo/KINGSTON/DREAD_DATASETS/mswepFJSmask_lec30_05deg_africa_nan_ERA5.nc /media/ulfo/KINGSTON/DREAD_DATASETS/${dataset}_monthly_${month}_regridded_19832014.nc /media/ulfo/KINGSTON/DREAD_DATASETS/${dataset}_monthly_${month}_regridded_19832014_newbimodal.nc

done
done
