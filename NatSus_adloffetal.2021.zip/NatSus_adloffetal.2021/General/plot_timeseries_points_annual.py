#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

from netCDF4 import Dataset
import numpy as np
import csv
import itertools
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import matplotlib.patches as patches
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)
from sklearn.linear_model import TheilSenRegressor
import scipy
import mkt


### Read in nc-files and produce csv ###

months = ['OND','MAM']
percentiles = ['0','95',]
years = np.arange(1979,2020)
n_years = np.arange(len(years))

points = ['A3','B3','C3','D3']
markers = ['s','D','^','o']
colors = ['midnightblue','firebrick','peru','gray']
styles = ['-',':']

fig = plt.figure()
ax = fig.add_subplot(111)
#plt.grid()

for percentile in range(len(percentiles)):

	for point in range(len(points)):

		for month in range(len(months)):
			
			read_file='MSWEP2_above_'+percentiles[percentile]+'pct_'+points[point]+'_'+months[month]+'_nan.nc'
			#if percentiles[percentile] == '0':
			#	read_file='MSWEP2_'+points[point]+'_'+months[month]+'_3.nc'
			data = Dataset(read_file, 'r')
			if month == 0:
				ext_prec = data.variables['precipitation'][:,0,0] #time
			else:
				ext_prec = ext_prec + data.variables['precipitation'][:,0,0] #time

		idx = np.isfinite(ext_prec[:])
		a_ext,b_ext = np.polyfit([n_years[i] for i in range(len(n_years)) if idx[i]],[ext_prec[i] for i in range(len(ext_prec[:])) if idx[i]],1)


		#p4 = ax.scatter(years[offset:],ext_prec[offset:], color=colors[point],marker=markers[point], s=10)
		#p5, = ax.plot(years[offset:],ext_prec[offset:], color=colors[point],linestyle=styles[percentile],linewidth=0.3)
		p6, = ax.plot(years[:],b_ext+a_ext*n_years[:],linestyle=styles[percentile], color=colors[point])


plt.xticks(rotation=45,fontsize=8)
ax.xaxis.set_minor_locator(MultipleLocator(1))
ax.yaxis.grid()
ax.set_ylim([0,600])
ax.set_ylabel('Rainfall [mm]')
#plt.subplots_adjust(top=0.8)
#plt.savefig(months[month]+'_'+percentiles[percentile]+'pct_points3.pdf')
plt.show()
	
