#! /usr/lib/python2.7
# -*- coding: utf-8 -*-

from netCDF4 import Dataset
import numpy as np
import csv

#readfiles = ['Jan','halfJanhalfFeb','Feb','Jun','Jul','halfJulhalfAug','Aug','Sep']
#period = ['1st - 31st Jan','15th Jan - 15th Feb', '1st - 28th Feb','1st - 30th June','1st - 31st Jul','15th Jul - 15th Aug','1st Aug - 31st Aug','1st - 30th Sep']
readfiles = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
period = ['Jan','Feb', 'Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
years = range(1981,2019)

with open('AI_newbimodal.csv','w') as f:
	for i in range(len(readfiles)):
	#read in netcdf files and create data lists ###
		print readfiles[i]
		data = Dataset('PET/fldmean_'+readfiles[i]+'_pet_EA_newbimodal.nc', 'r')
		#print data.variables
		pet = data.variables['pet'][:,:,:] #time
	
		data = Dataset('CHIRPS/fldmean_'+readfiles[i]+'_CHIRPS_EA_PET_newbimodal.nc', 'r')
		#print data.variables
		prec = data.variables['precip'][:,:,:] #time
	

		write=csv.writer(f,delimiter=',')
		for year in range(len(prec)):
			write.writerow([period[i],years[year],prec[year][0][0]/pet[year][0][0]])
