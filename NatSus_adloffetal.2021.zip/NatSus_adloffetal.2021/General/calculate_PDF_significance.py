#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

from netCDF4 import Dataset
import numpy as np
import scipy.stats as st

#file1 = ['7080','8090','9095']
#file2 = ['8090','9095','95100']

file1 = ['9095','95100']
file2 = ['9095','95100']

for i in range(len(file1)):

#	read_file='/media/ulfo/KINGSTON/DREAD_Datasets/timcor_MSWEP_above_daily_'+file1[i]+'perc_GRACE_OND_JJ_shift_bimodal.nc' #used for tables
	read_file='/media/ulfo/KINGSTON/DREAD_Datasets/timcor_MSWEP_above_daily_'+file1[i]+'perc_GRACE_OND_janfeb_shift_bimodal.nc' #used for Dave

	data = Dataset(read_file, 'r')
	#print data.variables
	lons = data.variables['lon'][:]
	lats = data.variables['lat'][:]
	trends1 = data.variables['precipitation'][:,:,:] #lat,lon

	#for i in range(len(lats)-1):
	#	if lats[i] > 6.5 and lats[i+1] <= 6.5 :
	#		latmin = i+1
	#	elif lats[i] >= -5 and lats[i+1] < -5 :
	#		latmax = i
	#for j in range(len(lons)-1):
	#	if lons[j] < 34.25 and lons[j+1] >= 34.25:
	#		lonmin = j
	latmin=0
	latmax=len(lats)-1
	lonmin=0	

	trends1 = np.ma.masked_invalid(sorted(trends1[0,lonmin:,latmin:latmax+1].flatten()))
	trends1 = trends1[~trends1.mask]
	
	for j in range(len(file2)):

#		read_file='/media/ulfo/KINGSTON/DREAD_Datasets/timcor_MSWEP_above_daily_'+file2[j]+'perc_GRACE_OND_JJ_shift_bimodal.nc' #used for tables
		read_file='/media/ulfo/KINGSTON/DREAD_Datasets/timcor_MSWEP_above_daily_'+file2[j]+'perc_GRACE_MAM_JJ_shift_bimodal.nc' #used for Dave

		data = Dataset(read_file, 'r')
		#print data.variables
		lons = data.variables['lon'][:]
		lats = data.variables['lat'][:]
		trends2 = data.variables['precipitation'][:,:,:] #lat,lon

		trends2 = np.ma.masked_invalid(sorted(trends2[0,lonmin:,latmin:latmax+1].flatten()))
		trends2 = trends2[~trends2.mask]

		print file1[i], file2[j]
		print st.anderson_ksamp([trends1,trends2],midrank=True)
		print st.ks_2samp(trends1,trends2)
		print np.mean(trends1), np.mean(trends2)
