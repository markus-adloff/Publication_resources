#! /usr/lib/python2.7
# -*- coding: utf-8 -*-

#from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
import numpy as np
import csv


###
# Plotting comparison between observational and reanalysis time series
###

def read_in(filename):

	years = []
	values = []

	with open(filename,'r') as f:
		read = csv.reader(f, delimiter=',')
		
		for row in read:
			if row[1] != 'nan':
				years.append(float(row[0]))
				values.append(float(row[1]))
	
	return years,values
			
####
# Main program
####

#read in observational data sets

years_CHIRPS, data_CHIRPS = read_in('MAMsum_EA_CHIRPSnewbimodal.csv')
years_CRU, data_CRU = read_in('MAMsum_EA_CRUnewbimodal.csv')
years_GPCC, data_GPCC = read_in('MAMsum_EA_GPCCnewbimodal.csv')
years_MSWEP, data_MSWEP = read_in('MAMsum_EA_MSWEP2newbimodal.csv')
years_ARC2, data_ARC2 = read_in('MAMsum_EA_ARC2newbimodal.csv')
years_ERA5, data_ERA5 = read_in('MAMsum_EA_ERA5newbimodal.csv')
#years_TRMM, data_TRMM = read_in('./TRMM/longrainsum_EA_TRMM.csv')
#years_TARCAT, data_TARCAT = read_in('ONDsum_EA_TAMSATbimodal.csv')

#read in reanalyses

#years_CFSR, data_CFSR = read_in('ONDsum_EA_CFSRbimodal.csv')
#years_ERA, data_ERA = read_in('ONDsum_EA_ERA-Iterimbimodal.csv')
#years_JRA, data_JRA = read_in('ONDsum_EA_JRA-55bimodal.csv')
#years_MERRA, data_MERRA = read_in('novsum_EA_MERRA2.csv')
#years_NCEP, data_NCEP = read_in('ONDsum_EA_NCEPbimodal.csv')

#read in models

#years_ECHAM, data_ECHAM = read_in('ONDsum_EA_ECHAM.csv')
#years_CAM4, data_CAM4 = read_in('ONDsum_EA_CAM4.csv')
#years_MIROC5, data_MIROC5 = read_in('ONDsum_EA_MIROC5.csv')
#years_NorESM, data_NorESM = read_in('ONDsum_EA_NorESM.csv')

#calculate trends

#datas = [data_CHIRPS, data_TRMM, data_TARCAT, data_CRU, data_GPCC, data_CFSR, data_ERA, data_JRA, data_MERRA, data_NCEP, data_ECHAM, data_CAM4, data_MIROC5, data_NorESM]
#times = [years_CHIRPS, years_TRMM, years_TARCAT, years_CRU, years_GPCC, years_CFSR, years_ERA, years_JRA, years_MERRA, years_NCEP, years_ECHAM, years_CAM4, years_MIROC5, years_NorESM]
#lin_trend_a = [np.nan for x in range(len(datas))]
#lin_trend_b = [np.nan for x in range(len(datas))]

#for i in range(len(datas)):
#	print i, times[i]
#	if i == 1:
#		#find start index
#		j = 0
#	else:
#		#find start index
#		j = list(times[i]).index(1983)
#
#	lin_trend_a[i],lin_trend_b[i] = np.polyfit(times[i][j:],datas[i][j:],1)
#	print i, lin_trend_a[i],lin_trend_b[i]


#create envelope around observations

#maxi = []
#mini = []

#for i in range(len(years_CRU)):
#	loc_data = []
	
#	for dataset in [data_CHIRPS, data_CRU, data_TRMM, data_TARCAT, data_GPCC]:
#	for dataset in [data_CHIRPS, data_CRU]:
#		if len(dataset) >= len(years_CRU) - i:
#			loc_data.append(dataset[-(len(years_CRU)-i)])	
			
#	maxi.append(max(np.asarray(loc_data)))
#	mini.append(min(np.asarray(loc_data)))

#create plot

def compare_reanalysis():
	fig = plt.figure()
	ax = fig.add_subplot(111)
#	p1 = ax.fill_between(years_CRU, maxi, mini, color='gray', alpha=0.5, label='observations')
	p2, = ax.plot(years_CRU, data_CRU, color='grey', label='CRU')
	p3, = ax.plot(years_GPCC, data_GPCC, color='grey', label='GPCC')
	p4, = ax.plot(years_CHIRPS, data_CHIRPS, color='grey', label='CHIRPS')
	#p5, = ax.plot(years_TARCAT, data_TARCAT, color='grey', label='TARCAT')
	p6, = ax.plot(years_JRA, data_JRA, color='turquoise', label='JRA-55')
	#p4, = ax.plot(years_MERRA, data_MERRA, color='khaki', label='MERRA2')
	p7, = ax.plot(years_NCEP, data_NCEP, color='darkcyan', label='NCEP')
	#p8, = ax.plot(years_CFSR, data_CFSR, color='royalblue', label='CFSR')
	p9, = ax.plot(years_ERA, data_ERA, color='darkblue', label='ERA')
	ax.set_xlabel('year',fontsize=18)
	ax.set_ylabel('cummulative precipitation [mm]',fontsize=18)
	ax.grid()
	ax.legend(loc=2,ncol=2)

	plt.show()
	#plt.savefig(filename)
	
def compare_models():
	fig = plt.figure()
	ax = fig.add_subplot(111)
#	p1 = ax.fill_between(years_CRU, maxi, mini, color='gray', alpha=0.5, label='observations')
	p2, = ax.plot(years_CRU, data_CRU, color='grey', label='CRU')
	p3, = ax.plot(years_GPCC, data_GPCC, color='grey', label='GPCC')
	p4, = ax.plot(years_CHIRPS, data_CHIRPS, color='grey', label='CHIRPS')
	#p5, = ax.plot(years_TARCAT, data_TARCAT, color='grey', label='TARCAT')
	p6, = ax.plot(years_ECHAM, data_ECHAM, color='turquoise', label='ECHAM6')
	p7, = ax.plot(years_NorESM, data_NorESM, color='darkcyan', label='NorESM')
	p8, = ax.plot(years_CAM4, data_CAM4, color='royalblue', label='CAM4')
	p9, = ax.plot(years_MIROC5, data_MIROC5, color='darkblue', label='MIROC5')
	ax.set_xlabel('year',fontsize=18)
	ax.set_ylabel('cummulative precipitation [mm]',fontsize=18)
	ax.grid()
	ax.legend(loc=2,ncol=2)

	plt.show()
	#plt.savefig(filename)
	
def compare_obs():

	fig = plt.figure()
	ax = fig.add_subplot(111)
	p2, = ax.plot(years_CRU, data_CRU, color='black', label='CRU')
	p3, = ax.plot(years_GPCC, data_GPCC, color='saddlebrown', label='GPCC')
	p4, = ax.plot(years_ARC2, data_ARC2, color='orangered', label='ARC2')
	p5, = ax.plot(years_CHIRPS, data_CHIRPS, color='orange', label='CHIRPS')
	p6, = ax.plot(years_MSWEP, data_MSWEP, color='grey', label='MSWEP')
	p7, = ax.plot(years_ERA5, data_ERA5, color='teal', label='ERA5')
	
	p8 = ax.scatter(years_CRU, data_CRU, marker='x', color='black')
	p9 = ax.scatter(years_GPCC, data_GPCC, marker='x', color='saddlebrown')
	p10 = ax.scatter(years_ARC2, data_ARC2, marker='x', color='orangered')
	p11 = ax.scatter(years_CHIRPS, data_CHIRPS, marker='x', color='orange')
	p12 = ax.scatter(years_MSWEP, data_MSWEP, marker='x', color='grey')
	p13 = ax.scatter(years_ERA5, data_ERA5, marker='x', color='teal')
#	p5 = ax.scatter(years_TARCAT, data_TARCAT, color='gray', label='TARCAT', marker='+')
	ax.set_xlabel('year',fontsize=18)
	ax.set_ylabel('cummulative rainfall [mm]',fontsize=18)
	ax.grid()
	ax.set_ylim([0,350])
	ax.set_xlim([1980,2020])
	ax.legend([p2,p3,p4,p5,p6,p7],['CRU','GPCC','ARC2','CHIRPS','MSWEP','ERA5'],loc=1,ncol=2)

	#plt.show()
	plt.savefig('/home/bridge/ma16749/RESULTS/timeseries_obs_MAMtots_newbimodal.pdf')

compare_obs()
