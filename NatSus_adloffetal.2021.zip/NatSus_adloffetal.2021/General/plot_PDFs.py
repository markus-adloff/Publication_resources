#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import cm
import numpy as np
import csv
import seaborn as sns
plt.rcParams["axes.labelsize"] = 20


### Read in csv file ###

#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_regridded_MSWEP_perc.csv')
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_regridded_chirpsextreme.csv')
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_regridded_grace.csv')
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/datamodel_means.csv')
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/swarmplot_trends_errors_bimodal.csv')
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/swarmplot_months_errors_noTAMSAT.csv')
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/swarmplot_trends_errors_obs-res_bimodal.csv')

# the most recent ones
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_regridded_newbimodal.csv') #old version
Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_regridded_newbimodal_MSWEP2.csv')
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_regridded_newbimodal_seasonal.csv') #old version
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_regridded_newbimodal_seasonal_MSWEP2.csv')

Data.head(0)

### Plot PDFs ###

def plot_seaborn():

	
	sns.set(font_scale = 1.5)
	sns.set_style("ticks")
	fig = plt.figure(figsize=(8,7))
	colours = ['brown','sienna','orange','gold','grey','teal',]
#	colours = ['brown','sienna','gold','grey','teal',]
#	colours = ['grey','brown','sienna','orange','gold']
	#colours = ['light blue','medium blue','teal','aqua']
#	colours = ['grey','cerulean','dark blue','dark turquoise','turquoise']
#	colours = ['brown','grey','cerulean','dark blue','dark turquoise','turquoise']
	sns.set_palette(sns.xkcd_palette(colours))
	
	ax=sns.catplot(x="Month", y="Trends [mm/yr]", hue="Dataset", kind="boxen", data=Data)
#	sns.catplot(x="Month", y="Trends [mm/yr]", hue="Dataset", kind="swarm", dodge=True, ax=ax, data=Data)
#	sns.catplot(x="Season", y="Trends [mm/yr]", hue="Dataset", kind="boxen", data=Data)
#	sns.catplot(x="Month", y="Change [mm]", hue="Dataset", kind="boxen", data=Data)
#	sns.catplot(x="Month", y="Mean prec. [mm]", hue="Dataset", kind="swarm", dodge=True,ax=ax,data=Data)
	plt.axhline(0,0,1,color='black')

	# Find the x,y coordinates for each point
#	x_coords = []
#	y_coords = []
#	for point_pair in ax.collections:
 #   		for x, y in point_pair.get_offsets():
  #      		x_coords.append(x)
   #     		y_coords.append(y)

#### swarmplot trends ####
#	errors = [np.asarray(Data['Trends [mm/yr]']) - np.asarray(Data['min. trend']),np.asarray(Data['max. trend']) - np.asarray(Data['Trends [mm/yr]'])]
### normal ###
#	colors = ['brown']*4 + ['grey']*4 + ['white']*43 + ['brown']*4 + ['grey']*4 + ['white']*43 + ['brown']*4 + ['grey']*4 + ['white']*43 + ['brown']*4 + ['grey']*4 + ['white']*43 + ['brown']*4 + ['grey']*4 + ['white']*43
### no TAMSAT ###
#	colors = ['brown']*3 + ['grey']*4 + ['white']*43 + ['brown']*3 + ['grey']*4 + ['white']*43 + ['brown']*3 + ['grey']*4 + ['white']*43 + ['brown']*3 + ['grey']*4 + ['white']*43 + ['brown']*3 + ['grey']*4 + ['white']*43	
### obs-res ###
#	errors = [np.asarray(Data['Trends [mm/yr]']) - np.asarray(Data['min. trend']),np.asarray(Data['max. trend']) - np.asarray(Data['Trends [mm/yr]'])]
#	colors = ['grey']*3 + ['blue']*3 + ['grey']*3 + ['blue']*3 + ['grey']*3 + ['blue']*3 + ['grey']*3 + ['blue']*3 + ['grey']*3 + ['blue']*3

### swarmplot months ###
#	errors = [np.asarray(Data['Mean prec. [mm]']) - np.asarray(Data['std']),np.asarray(Data['Mean prec. [mm]']) + np.asarray(Data['std'])]
#	colors = ['grey']*3 + ['blue']*3 + ['grey']*3 + ['blue']*3 + ['grey']*3 + ['blue']*3 + ['grey']*3 + ['blue']*3 + ['grey']*3 + ['blue']*3
#	print len(x_coords),len(y_coords)
#	ax.errorbar(x_coords, y_coords, yerr=errors,
#	    ecolor=colors, fmt=' ', zorder=-1)
#	ax.legend(bbox_to_anchor=(1.15, 0.4),loc=8)
	ax.set_xticklabels(['Mar', 'Apr','May', 'Oct', 'Nov','Dec'])
#	ax.set_xticklabels(['MAM', 'OND'])
	plt.xlabel('Month')
	plt.subplots_adjust(bottom=0.15)
#	plt.savefig('boxen_monthly_trends_bimodal_19832014_MSWEP2.pdf')
	plt.show()
	
plot_seaborn()

