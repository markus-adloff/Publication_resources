#!/bin/bash -l


for data in MSWEP2 #ARC2 CRU CHIRPS GPCC ERA5 MSWEP2 #TAMSAT
do

cdo remapcon2,MSWEP2/grid_ERA5.txt ${data}/${data}_MAM.nc ${data}_MAM_05deg_ERA5.nc
cdo ifthen MSWEP2/mswepFJSmask_lec30_05deg_africa_nan_ERA5.nc ${data}_MAM_05deg_ERA5.nc ${data}_MAM_05deg_ERA5_newbimodal.nc
cdo fldmean -setname,prec ${data}_MAM_05deg_ERA5_newbimodal.nc ${data}_MAM_timeseries_newbimodal.nc
#cdo fldmean -setname,prec -setctomiss,0 -setctomiss,-9999 -sellonlatbox,37,54.25,-4.5,8 ${data}/${data}_MAM.nc ${data}_MAM_timeseries.nc #old version
#cdo fldmean -setname,prec -setctomiss,0 -setclonlatbox,0,42.5,54,12.5,16 -setctomiss,-9999 -sellonlatbox,33,54,-10,16 ${data}/${data}_MAM_v3_corrected.nc ${data}_MAM_timeseries.nc #old TMASAT version

done


#cdo -sellonlatbox,37,54.25,-4.5,8 GPCC/GPCC_MAM.nc GPCC/GPCC_MAM_reg.nc
#cdo -setclonlatbox,0,42.5,54,12.5,8 GPCC/GPCC_MAM_reg.nc GPCC/GPCC_MAM_reg2.nc
#cdo -setctomiss,0 GPCC/GPCC_MAM_reg2.nc GPCC/GPCC_MAM_reg3.nc
#cdo -setname,prec GPCC/GPCC_MAM_reg3.nc GPCC/GPCC_MAM_reg4.nc
#cdo fldmean GPCC/GPCC_MAM_reg4.nc GPCC_MAM_timeseries.nc

#cdo -sellonlatbox,37,54.25,-4.5,8 MSWEP/mswep_tot_MAM.nc MSWEP/MSWEP_MAM_reg.nc
#cdo -setclonlatbox,0,42.5,54,12.5,8 MSWEP/MSWEP_MAM_reg.nc MSWEP/MSWEP_MAM_reg2.nc
#cdo -setctomiss,0 MSWEP/MSWEP_MAM_reg2.nc MSWEP/MSWEP_MAM_reg3.nc
#cdo -setname,prec MSWEP/MSWEP_MAM_reg.nc MSWEP/MSWEP_MAM_reg4.nc
#cdo fldmean MSWEP/MSWEP_MAM_reg4.nc MSWEP_MAM_timeseries.nc

#cdo -sellonlatbox,37,54.25,-4.5,8 ERA5/ERA5_MAM.nc ERA5/ERA5_MAM_reg.nc
#cdo -setname,prec ERA5/ERA5_MAM_reg.nc ERA5/ERA5_MAM_reg4.nc
#cdo fldmean ERA5/ERA5_MAM_reg4.nc ERA5_MAM_timeseries.nc

