#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import cm
import numpy as np
import csv
import seaborn as sns
from netCDF4 import Dataset
import matplotlib.patches as patches
from sklearn.linear_model import TheilSenRegressor
import scipy


### Read in csv files ###
infile='/media/ulfo/KINGSTON/DREAD_Datasets/dataset_raintotals_MAM_0.csv'
tot_Data=pd.read_csv(infile)
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_raintotals_MAM_R99.csv')
tot_Data.head(0)
tot_years = []
tot_prec = []
with open(infile) as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
	if not row[0] == 'Year':
		tot_years.append(row[0])
		tot_prec.append(row[1])

infile='/media/ulfo/KINGSTON/DREAD_Datasets/dataset_raintotals_MAM_R99.csv'
Data=pd.read_csv(infile)
#Data=pd.read_csv('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_raintotals_MAM_R99.csv')
Data.head(0)
years = []
prec = []
with open(infile) as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
	if not row[0] == 'Year':
		years.append(row[0])
		prec.append(row[1])

### Plot PDFs ###

def plot_seaborn():

	fig = plt.figure()

	sns.set_style("whitegrid")
	ax1 = sns.boxplot(x="Year", y="Precipitation (mm)", data=Data, showfliers=False, palette="Blues_r")
	#ax = sns.swarmplot(x="Rain rate percentile (%)", y="Covariance", data=Data,size=0.5,linewidth=1)
	ax1.set_ylim([0,800])
	labels = [item.get_text() for item in ax1.get_xticklabels()]
	plt.locator_params(axis='x', nbins=12)
	labels_new = [labels[i] for i in range(0,len(labels),3)]
	ax1.set_xticklabels(np.asarray(labels_new))
	plt.xlabel("Year", fontsize=15)
	plt.ylabel("Precipitation (mm)", fontsize=15)

	plt.show()

def plot_trends_test():

	means = Data.groupby('Year').mean()
	years = Data.drop_duplicates(subset='Year')
	print len(years['Year']),len(means)
	a,b = np.polyfit(years['Year'],means['Precipitation (mm)'],1)

	fig = plt.figure()
	ax = fig.add_subplot(111)
	p1 = ax.scatter(years['Year'],means['Precipitation (mm)'], color='limegreen', linewidth=3)
	p2 = ax.plot(years['Year'],b+a*np.asarray(years['Year']),color='black')
	ax.set_ylim([0,800])
	plt.show()

def plot_trends():

	month='MAM'
	time = np.arange(1979,2015)
	read_file='/media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/0/mswep_0_'+str(month)+'_lsm_bimodal_mean.nc'
	data = Dataset(read_file, 'r')
	#print data.variables
	all_prec = data.variables['precipitation'][:,0,0] #time

	read_file='/media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_R99_'+str(month)+'_lsm_bimodal_mean.nc'
	data = Dataset(read_file, 'r')
	ext_prec = data.variables['precipitation'][:,0,0] #time

	a,b = np.polyfit(time,all_prec,1)
	a_ext,b_ext = np.polyfit(time,ext_prec,1)
	print a, a_ext

	fig = plt.figure()
	ax = fig.add_subplot(111)
	p1 = ax.scatter(time,all_prec, color='limegreen', linewidth=3)
	p2 = ax.plot(time,b+a*np.asarray(time),color='black')
	p3 = ax.scatter(time,ext_prec, color='limegreen', linewidth=3)
	p4 = ax.plot(time,b_ext+a_ext*np.asarray(time),color='black')
	ax.set_ylim([0,800])
	plt.show()

def plot_totals_and_trends():

	month='MAM'
	time = np.arange(0,34)
	read_file='/media/ulfo/KINGSTON/DREAD_Datasets/MSWEP_percentiles/Full_period/0/mswep_0_'+str(month)+'_lsm_bimodal_mean.nc'
	tot_data = Dataset(read_file, 'r')
	#print data.variables
	all_prec = tot_data.variables['precipitation'][2:,0,0] #time

	read_file='/media/ulfo/KINGSTON/DREAD_Datasets/To_Markus/rainy_seas/mswep_full_R99_'+str(month)+'_lsm_bimodal_mean.nc'
	data = Dataset(read_file, 'r')
	ext_prec = data.variables['precipitation'][2:,0,0] #time

#	a,b = np.polyfit(time,all_prec,1)
	reg = TheilSenRegressor(random_state=0).fit(np.asarray(years).reshape(-1,1),prec)
#	reg = TheilSenRegressor(random_state=0).fit(np.asarray(time).reshape(-1,1),ext_prec)
#    	a,b = scipy.stats.theilslopes(Data["Year"],Data["Precipitation (mm)"])
#	a_ext,b_ext = np.polyfit(time,ext_prec,1)
	predict_y=TheilSenRegressor.predict(reg,np.linspace(1981,2014,num=34,endpoint=True).reshape(-1,1))
#	predict_y=TheilSenRegressor.predict(reg,time.reshape(-1,1))
	a,b = np.polyfit(np.linspace(1981,2014,num=34,endpoint=True),predict_y,1)
#	a,b = np.polyfit(time,predict_y,1)
#	score = reg.score(np.asarray(years).reshape(-1,1),prec)

	fig = plt.figure()
	sns.set_style("whitegrid")

	ax = sns.boxplot(x="Year", y="Precipitation (mm)", data=tot_Data, showfliers=False, color="whitesmoke",zorder=0)
	ax = sns.boxplot(x="Year", y="Precipitation (mm)", data=Data, showfliers=False, color="steelblue")
	labels = [item.get_text() for item in ax.get_xticklabels()]
	plt.locator_params(axis='x', nbins=12)
	labels_new = [labels[i] for i in range(0,len(labels),3)]
	ax.set_xticklabels(np.asarray(labels_new))
	plt.ylabel("Precipitation (mm)", fontsize=15)
	plt.xlabel("Year", fontsize=15)

	ax2 = ax.twinx()
#	p1 = ax2.scatter(time,all_prec, color='limegreen', linewidth=3)
#	p2 = ax2.plot(time,b+a*np.asarray(time),color='black')
#	p3 = ax2.scatter(time,ext_prec, color='slategray', linewidth=3)
#	p4, = ax2.plot(time,b+a*np.asarray(time),color='black')
	p4, = ax2.plot(time,predict_y,color='black')
#	ax2.legend([p3,p4,patches.Rectangle((0,0),2,0.05,linewidth=1,facecolor='gainsboro',edgecolor='black')], ['linear approximation \n slope = 2.6 mm/yr','distribution of \n local rainfall totals'], loc=2,fontsize=10)
#	ax2.legend([p4,patches.Rectangle((0,0),2,0.05,linewidth=1,facecolor='gainsboro',edgecolor='black')], ['linear approximation \n slope = '+str(round(a,2))+' mm/yr, R$^2$ = '+str(round(score,2)),'distribution of \n local rainfall totals'], loc=2,fontsize=10)
	ax2.legend([p4,patches.Rectangle((0,0),2,0.05,linewidth=1,facecolor='gainsboro',edgecolor='gray'),patches.Rectangle((0,0),2,0.05,linewidth=1,facecolor='steelblue',edgecolor='black')], ['linear approximation \n slope = '+str(round(a,2))+' mm/yr','distribution of \n local total rainfall','distribution of \n local extreme rainfall'], loc=2,fontsize=10)
	ax.set_ylim([0,800])
	ax2.set_ylim([0,800])
	plt.setp(ax2.yaxis.get_major_ticks(), visible=False)
	plt.setp(ax2.yaxis.get_minor_ticks(), visible=False)

	plt.show()
	#plt.savefig(month+'_timeseries_extremes.pdf')

#plot_seaborn()
plot_totals_and_trends()

