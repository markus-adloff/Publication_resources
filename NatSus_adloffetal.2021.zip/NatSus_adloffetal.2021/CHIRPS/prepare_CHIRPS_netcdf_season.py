#! /usr/lib/python2.7
# -*- coding: utf-8 -*-

import time
import sys
from netCDF4 import Dataset
from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
from matplotlib import cm
from PIL import Image
from scipy.stats import ttest_ind,t
import scipy.stats as st
import numpy as np
import csv
import mkt

### produce NetCDF file for CHIRPS ###

### 		  ###
#   General input   #
		    #
startyear = 1981    #
endyear = 2017	    #
region = 'yes'	    #
period = 'JJA'#  ## annualprec, lrprec or srprec
		    #
###		  ###


### create time array ###

if period == 'annualprec':
	months = [x for x in range(1,13)]
elif period == 'lrprec':
	months = [x for x in (3,4,5,6)]
elif period == 'srprec':
	months = [x for x in (9,10,11)]
elif period == 'JJA':
	months = [x for x in (6,7,8)]
elif period == 'MAM':
	months = [x for x in (3,4,5)]
elif period == 'ON':
	months = [x for x in (10,11)]
elif period == 'OND':
	months = [x for x in (10,11,12)]


years = np.arange(startyear,endyear+1)

lons = [float(x)/100. for x in range(-1997,-1997+5*1500,5)]
lats = [float(x)/100. for x in range(-3997,-3997+5*1600,5)]


### read in .tif files and create data lists ###

data_gz = {}
prec_annual = [[[np.nan for x in range(len(lons))] for y in range(len(lats))] for t in range(len(years))]
for year in range(startyear,endyear+1):
	for mon in months:
		if mon <= 9:
			month = '0'+str(mon)
		else: month = str(mon)
		yearmonth = int(year)*100+mon
		im = Image.open('../CHIRPS/africa_month/chirps-v2.0.'+str(year)+'.'+month+'.tif')
			
		data_gz.update({yearmonth:np.array(im)})
		data_gz[yearmonth][data_gz[yearmonth] < 0.] = np.nan
	
		for lat in range(len(lats)):
			for lon in range(len(lons)):
				if np.isnan(data_gz[yearmonth][lat][lon]) == False:
					if np.isnan(prec_annual[year-startyear][lat][lon]) == True:
						prec_annual[year-startyear][lat][lon] = float(data_gz[yearmonth][lat][lon])
					else:
						prec_annual[year-startyear][lat][lon] = prec_annual[year-startyear][lat][lon] + float(data_gz[yearmonth][lat][lon])
		
def writing_to_netcdf(data_to_write,filename,lon,lat,years):

	write_file='CHIRPS_'+filename+'.nc'

	dataset = Dataset(write_file, 'w',format='NETCDF3_CLASSIC')
	lo = dataset.createDimension('lon', len(lon)) 
	la = dataset.createDimension('lat', len(lat))
	tim = dataset.createDimension('time', len(years))

	longitudes = dataset.createVariable('lon', np.dtype('float32'), ('lon',))
	latitudes = dataset.createVariable('lat', np.dtype('float32'), ('lat',))
	times = dataset.createVariable('time', np.dtype('float32'), ('time',))
	the_data = dataset.createVariable('prec', np.dtype('float32'), ('time','lat','lon'), fill_value = -9999) 
	
	longitudes[:] = lon
	latitudes[:] = lat
	times[:] = years
	the_data[:,:] = data_to_write

	longitudes.units = 'degrees_east'
	latitudes.units = 'degrees_north'
	times.units = 'year'
	the_data.units = 'mm'

	dataset.history = 'Created ' + time.ctime(time.time())

	dataset.close()
	
lats = list(reversed(lats))
prec_annual = np.ma.masked_invalid(prec_annual)
writing_to_netcdf(prec_annual,'JJA',lons,lats,years)
	
