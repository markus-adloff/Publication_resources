#!/bin/bash -l

for year in {1981..2016..1}
do

cdo remapcon2,GRACE_grid_05_EA.txt ./global_pentad/chirps-v2.0.${year}.pentads.nc CHIRPS_pentads_GRACE_${year}.nc

done

cdo mergetime CHIRPS_pentads_GRACE_????.nc CHIRPS_pentads_GRACE.nc
rm CHIRPS_pentads_GRACE_????.nc

cdo yearsum -selmon,3/5 CHIRPS_pentads_GRACE.nc CHIRPS_pentads_MAM_GRACE.nc
cdo yearsum -selmon,10/12 CHIRPS_pentads_GRACE.nc CHIRPS_pentads_OND_GRACE.nc
cdo yearsum CHIRPS_pentads_GRACE.nc CHIRPS_pentads_annual_GRACE.nc
