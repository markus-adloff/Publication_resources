#! /usr/lib/python2.7
# -*- coding: utf-8 -*-

import time
import sys
from netCDF4 import Dataset
from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
from matplotlib import cm
from PIL import Image
from scipy.stats import ttest_ind,t
import scipy.stats as st
import numpy as np
import csv
import mkt

### 		  ###
#   General input   #
		    #
startyear = 1981    #
endyear = 2017	    #
region = 'yes'	    #
		    #
###		  ###


#read in netcdf files and create data lists ###

read_file='CHIRPS_annual.nc'

data = Dataset(read_file, 'r')
#print data.variables
lons = data.variables['lon'][:]
lats = data.variables['lat'][:]
prec_annual = data.variables['prec'][:,:,:] #time,lat,lon


### find lon and lat ###

if region == 'yes':
	for i in range(len(lons)-1):
		if lons[i] <= 33 and lons[i+1] > 33:
			lonmin = i
		elif lons[i] <= 54. and lons[i+1] > 54.:
			lonmax = i
	for i in range(len(lats)-1):
		if lats[i+1] <= -10. and lats[i] > -10.:
			latmin = i
		elif lats[i+1] <= 16. and lats[i] > 16. :
			latmax = i

else:
	lonmin,lonmax,latmax,latmin = 0,len(lons),len(lats),0
	
las = []
los = []
			
#for la,lo in [(7.3,40.9),(11.9,39.4),(4.3,46.3)]:
#	for i in range(len(lons)):
#		if lons[i] <= lo and lons[i+1] > lo:
#			los.append(i)
#	for i in range(len(lats)):
#		if lats[i] <= la and lats[i+1] > la:
#			las.append(i)


### calculate linear trend ###
def trending(prec_annual,idx_years,idx):

	### test if actual prec_annual and prec_annual_guess, calculated via the regression function, are the same population at a significant level ###
	print lonmax, latmax

	lin_trend_a = [[0 for x in range(lonmin,lonmax)] for y in range(latmax,latmin)]
	lin_trend_b = [[0 for x in range(lonmin,lonmax)] for y in range(latmax,latmin)]
#	tvalue = [[0 for x in range(len(data_gz[startyear*100+1][0]))] for y in range(len(data_gz[startyear*100+1]))]
#	pvalue = [[0 for x in range(len(data_gz[startyear*100+1][0]))] for y in range(len(data_gz[startyear*100+1]))]
	T_zero = [[0 for x in range(lonmin,lonmax)] for y in range(latmax,latmin)]
	p_values = [[0 for x in range(lonmin,lonmax)] for y in range(latmax,latmin)]
	for lat in range(latmin-latmax):
		for lon in range(lonmax-lonmin):
			if np.isnan(prec_annual[1][latmax+lat][lonmin+lon]) == False:
				a,lin_trend_a[lat][lon],lin_trend_b[lat][lon],p_values[lat][lon] = mkt.test(np.asarray(idx_years),np.asarray([prec_annual[x][latmax+lat][lonmin+lon] for x in idx]),0.001,0.95,'upordown')
				T_zero[lat][lon] = st.norm.ppf(T_zero[lat][lon])
			#	lin_trend_a[lat][lon],lin_trend_b[lat][lon] = np.polyfit(idx_years,[prec_annual[x][latmin+lat][lonmin+lon] for x in idx],1)
			#	tvalue, pvalue = scipy.stats.ttest_ind([prec_annual[x][lat][lon] for x in range(len(years))], [trends[lat][lon][0]*x + trends[lat][lon][1] for x in years], equal_var=False) --> I need to get the significance for a trent != 0
			#	s_e = np.sqrt((np.nansum((np.asarray([prec_annual[x][latmin+lat][lonmin+lon] for x in idx]) - np.asarray([lin_trend_a[lat][lon]*x + lin_trend_b[lat][lon] for x in idx_years]))**2)/(len(idx_years)-2.))/(np.sum((np.asarray(idx_years) - np.mean(idx_years))**2)))
			#	T_zero[lat][lon] = (lin_trend_a[lat][lon] - 0.)/s_e


	lin_trendm = np.ma.masked_inside(T_zero,-t.ppf(0.9,df=len(idx_years)-2),t.ppf(0.9,df=len(idx_years)-2))
	
	return lin_trend_a, lin_trend_b, lin_trendm,p_values

### plot ###

def plot_local_trend(data,lin_trend_a,lin_trend_b,time,caption,lat,lon):

	fig = plt.figure()
	ax = fig.add_subplot(111)
	p1 = ax.scatter(time, [data[x][lat][lon] for x in range(len(years))], color='gray', label='data')
	p2, = ax.plot(time,[lin_trend_a[lat-latmin][lon-lonmin]*x + lin_trend_b[lat-latmin][lon-lonmin] for x in years], color='black', label='regression')
	ax.set_xlabel('month',fontsize=18)
	ax.set_ylabel('precipitation sum [mm]',fontsize=18)
	ax.grid()
	ax.legend(loc=2)

	plt.show()
#	plt.savefig(filename)

def plot_2D(data,significance,caption,lon,lat,startyear):

	fig = plt.figure(figsize=(5,7))
	m = Basemap(projection='merc', lat_0=0, lon_0=0,\
	    urcrnrlat=lat[0],llcrnrlat=lat[len(lat)-1],\
            llcrnrlon=lon[0],urcrnrlon=lon[len(lon)-1],resolution='l')

	x_mesh,y_mesh = np.meshgrid(lon,lat,indexing='ij')
	x,y = m(x_mesh,y_mesh)
	v,w = m(33,0)
	m.drawcountries()
	m.drawcoastlines()
	p1 = m.pcolormesh(x,y,data,cmap=cm.BrBG,vmin=-10,vmax=10)
	p2 = m.pcolor(x,y,significance, hatch='//', alpha=0.)
	cb = plt.colorbar(p1)
#	cb.ax.set_yticklabels(cb.ax.get_yticklabels(),rotation=90)
	cb.set_label(label = 'Precipitation trend [mm/yr]',fontsize=18)
#	m.set_ylim([lon[0],lon[len(lon)-1]])
#	m.set_xlim([lat[0],lat[len(lat)-1]])
#	m.set_xlabel('lat', fontsize=18)
#	plt.setp( m.yaxis.get_majorticklabels(), rotation=90 )
#	m.set_ylabel('lon', fontsize=18)
#	plt.setp( m.xaxis.get_majorticklabels(), rotation=90 )

	plt.show()
#	filename="trends_1981-"+str(endyear)+"_annualprec_CRU"+str(startyear)+".png"
#	plt.savefig(filename)

#for i in range(len(las)):
#	plot_local_trend(prec_annual,lin_trend_a,lin_trend_b,years,'yearly precipitation',las[i],los[i])

#lin_trend_a = np.asarray(lin_trend_a).T
#lin_trendm = np.swapaxes(lin_trendm,0,1)
#print lin_trend_a
#plot_2D(np.swapaxes(lin_trend_a,0,1),np.swapaxes(lin_trendm,0,1),'precipitation trends [mm]',lons[lonmin:lonmax],lats[latmin:latmax])

#trends over moving 30-year windows
#total_trends = [[0 for x in range(lonmin,lonmax)] for y in range(latmin,latmax)]
#total_trendsm = [[0 for x in range(lonmin,lonmax)] for y in range(latmin,latmax)]
#lin_trendm_int = [[0 for x in range(lonmin,lonmax)] for y in range(latmin,latmax)]
#count = 0
#for i in range(1950,2005-31):
#	years = np.arange(i,i+30.+1)
#	print years
#	offset = i - 1901
#	idx = [x for x in range(offset,offset+31)]
#	lin_trend_a,lin_trend_b,lin_trendm = trending(prec_annual,years,idx)
#	total_trendsm = [[x[k]+y[k] for k in range(len(x))] for x,y in zip(total_trendsm, lin_trendm)]
#	total_trends = [[x[k]+y[k] for k in range(len(x))] for x,y in zip(total_trends, lin_trend_a)]
#	print len(total_trendsm), len(total_trendsm[0])
#	#plot_2D(np.swapaxes(lin_trend_a,0,1),np.swapaxes(lin_trendm,0,1),'precipitation trends [mm]',lons[lonmin:lonmax],lats[latmin:latmax],i)
#	for k in range(len(lin_trendm_int)):
#		lin_trendm_int[k] = [np.nan if lin_trendm.mask[k][x] == True else lin_trendm_int[k][x] for x in range(len(lin_trendm[k]))]  
#	count = count +1

def writing_to_netcdf(data_to_write,filename,lon,lat):

	write_file='CHIRPS_'+filename+'.nc'

	dataset = Dataset(write_file, 'w',format='NETCDF3_CLASSIC')
	lo = dataset.createDimension('lon', len(lon)) 
	la = dataset.createDimension('lat', len(lat))
	tim = dataset.createDimension('time', 1)

	longitudes = dataset.createVariable('lon', np.dtype('float32'), ('lon',))
	latitudes = dataset.createVariable('lat', np.dtype('float32'), ('lat',))
	times = dataset.createVariable('time', np.dtype('float32'), ('time',))
	the_data = dataset.createVariable('prec', np.dtype('float32'), ('lat','lon'), fill_value = -9999) 
	
	longitudes[:] = lon
	latitudes[:] = lat
	times[0] = 1.
	the_data[:,:] = data_to_write

	longitudes.units = 'degrees_east'
	latitudes.units = 'degrees_north'
	times.units = 'year+dekade'
	the_data.units = 'mm'

	dataset.history = 'Created ' + time.ctime(time.time())

	dataset.close()
	
def multitest_significance(T_zero,q,df):

	all_sigs = np.asarray(T_zero).flatten()
	print all_sigs
	all_sigs = all_sigs[np.logical_not(np.isnan(all_sigs))]
	k=np.sort(all_sigs)[0]
	for i in range(len(all_sigs)-1):
		if np.sort(all_sigs)[i] <= q*i/len(all_sigs) and np.sort(all_sigs)[i+1] > q*i/len(all_sigs):
			if np.sort(all_sigs)[i] > k:
				k = np.sort(all_sigs)[i]
	T_zero_new = np.ma.masked_greater(T_zero,k)
	T_zero_new[T_zero_new == 0.] = np.nan
	T_zero_new2 = np.ma.masked_invalid(T_zero_new)
	return T_zero_new2

	
#lin_trendm_all = np.ma.masked_invalid(lin_trendm_int)

#print lin_trendm_all
#plot_2D(np.asarray(lin_trend_a).T,np.swapaxes(lin_trendm_all,0,1),str(i),lons[lonmin:lonmax],lats[latmin:latmax],i)
	
#total_trends_a = [[x[k]/float(count) for k in range(len(x))] for x in total_trends]
#plot_2D(np.swapaxes(total_trends_a,0,1),np.swapaxes(total_trendsm,0,1),'precipitation trends [mm]',lons[lonmin:lonmax],lats[latmin:latmax],'average_trend')

startyear = 2002
endyear = 2017
offset = startyear - 1981
years = np.arange(startyear,endyear+1)
#lin_trendm_int = [[0 for x in range(lonmin,lonmax)] for y in range(latmax,latmin)]
#for i in years:
#	j = list(years).index(i)
#	idx_years = list(np.copy(years))
#	del idx_years[j]
#	idx = [offset+x for x in range(len(years)) if (x != j)]
#	lin_trend_a,lin_trend_b,lin_trendm = trending(prec_annual,np.asarray(idx_years),idx)
#	for k in range(len(lin_trendm_int)):
#		lin_trendm_int[k] = [np.nan if lin_trendm.mask[k][x] == True else lin_trendm_int[k][x] for x in range(len(lin_trendm[k]))]  
#lin_trendm_all = np.ma.masked_invalid(lin_trendm_int)
lin_trend_a,lin_trend_b,lin_trendm,T_zero = trending(prec_annual,years,[offset+x for x in range(len(years))])

T_zero_new = multitest_significance(T_zero,0.1,len(years)-2)

#for i in range(len(las)):
#	plot_local_trend(prec_annual,lin_trend_a,lin_trend_b,years,'yearly precipitation',las[i],los[i])

writing_to_netcdf(lin_trend_a,'annual_2002-2017',lons[lonmin:lonmax],lats[latmin:latmax])
writing_to_netcdf(lin_trendm,'annual_2002-2017_sig',lons[lonmin:lonmax],lats[latmin:latmax])
	
#print lin_trendm_all
plot_2D(np.asarray(lin_trend_a).T,np.swapaxes(T_zero_new,0,1),str(i),lons[lonmin:lonmax],lats[latmax:latmin],i)
