#!/bin/bash -l

#for year in {1981..2018..1}
#do
#cdo -sellonlatbox,32,56,-11,18 global_pentad/chirps-v2.0.${year}.pentads.nc ${year}_CHIRPS_pentads_EA.nc

#cdo timsum -seltimestep,3/9/1 ${year}_CHIRPS_pentads_EA.nc ${year}_halfJanhalfFeb_CHIRPS_EA.nc
#cdo timsum -seltimestep,33/39/1 ${year}_CHIRPS_pentads_EA.nc ${year}_halfJunhalfJul_CHIRPS_EA.nc
#cdo timsum -setyear,${year} -seltimestep,42/48/1 ${year}_CHIRPS_pentads_EA.nc ${year}_halfJulhalfAug_CHIRPS_EA.nc

#cdo timsum -selmon,1 ${year}_CHIRPS_pentads_EA.nc ${year}_Jan_CHIRPS_EA.nc
#cdo timsum -selmon,2 ${year}_CHIRPS_pentads_EA.nc ${year}_Feb_CHIRPS_EA.nc
#cdo timsum -selmon,3 ${year}_CHIRPS_pentads_EA.nc ${year}_Mar_CHIRPS_EA.nc
#cdo timsum -selmon,4 ${year}_CHIRPS_pentads_EA.nc ${year}_Apr_CHIRPS_EA.nc
#cdo timsum -selmon,5 ${year}_CHIRPS_pentads_EA.nc ${year}_May_CHIRPS_EA.nc
#cdo timsum -selmon,6 ${year}_CHIRPS_pentads_EA.nc ${year}_Jun_CHIRPS_EA.nc
#cdo timsum -selmon,7 ${year}_CHIRPS_pentads_EA.nc ${year}_Jul_CHIRPS_EA.nc
#cdo timsum -selmon,8 ${year}_CHIRPS_pentads_EA.nc ${year}_Aug_CHIRPS_EA.nc
#cdo timsum -selmon,9 ${year}_CHIRPS_pentads_EA.nc ${year}_Sep_CHIRPS_EA.nc
#cdo timsum -selmon,10 ${year}_CHIRPS_pentads_EA.nc ${year}_Oct_CHIRPS_EA.nc
#cdo timsum -selmon,11 ${year}_CHIRPS_pentads_EA.nc ${year}_Nov_CHIRPS_EA.nc
#cdo timsum -selmon,12 ${year}_CHIRPS_pentads_EA.nc ${year}_Dec_CHIRPS_EA.nc

#rm ${year}_CHIRPS_pentads_EA.nc

#done

#cdo -mergetime ????_halfJanhalfFeb_CHIRPS_EA.nc halfJanhalfFeb_CHIRPS_EA.nc
#cdo -mergetime ????_halfJunhalfJul_CHIRPS.nc halfJunhalfJul_CHIRPS_EA.nc
#cdo -mergetime ????_halfJulhalfAug_CHIRPS_EA.nc halfJulhalfAug_CHIRPS_EA.nc
#cdo -mergetime ????_Jan_CHIRPS_EA.nc Jan_CHIRPS_EA.nc
#cdo -mergetime ????_Feb_CHIRPS_EA.nc Feb_CHIRPS_EA.nc
#cdo -mergetime ????_Mar_CHIRPS_EA.nc Mar_CHIRPS_EA.nc
#cdo -mergetime ????_Apr_CHIRPS_EA.nc Apr_CHIRPS_EA.nc
#cdo -mergetime ????_May_CHIRPS_EA.nc May_CHIRPS_EA.nc
#cdo -mergetime ????_Jun_CHIRPS_EA.nc Jun_CHIRPS_EA.nc
#cdo -mergetime ????_Jul_CHIRPS_EA.nc Jul_CHIRPS_EA.nc
#cdo -mergetime ????_Aug_CHIRPS_EA.nc Aug_CHIRPS_EA.nc
#cdo -mergetime ????_Sep_CHIRPS_EA.nc Sep_CHIRPS_EA.nc
#cdo -mergetime ????_Oct_CHIRPS_EA.nc Oct_CHIRPS_EA.nc
#cdo -mergetime ????_Nov_CHIRPS_EA.nc Nov_CHIRPS_EA.nc
#cdo -mergetime ????_Dec_CHIRPS_EA.nc Dec_CHIRPS_EA.nc

#cdo remapcon2,../PET/grid_PET_EA.txt halfJanhalfFeb_CHIRPS_EA.nc halfJanhalfFeb_CHIRPS_EA_PET.nc
#cdo remapcon2,../PET/grid_PET_EA.txt halfJunhalfJul_CHIRPS_EA.nc halfJunhalfJul_CHIRPS_EA_PET.nc
#cdo remapcon2,../PET/grid_PET_EA.txt halfJulhalfAug_CHIRPS_EA.nc halfJulhalfAug_CHIRPS_EA_PET.nc

for month in Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec
do

cdo remapcon2,../PET/grid_PET_EA.txt ${month}_CHIRPS_EA.nc ${month}_CHIRPS_EA_PET.nc
cdo ifthen ../PET/mswepFJSmask_lec30_invertlat_EA.nc ${month}_CHIRPS_EA_PET.nc ${month}_CHIRPS_EA_PET_newbimodal.nc
cdo masklonlatbox,32,56,-11,12 ${month}_CHIRPS_EA_PET_newbimodal.nc ${month}_CHIRPS_EA_PET_newbimodal_nan.nc
cdo fldmean ${month}_CHIRPS_EA_PET_newbimodal_nan.nc fldmean_${month}_CHIRPS_EA_PET_newbimodal.nc

done
