#!/bin/bash -l

#cdo -mergetime ???_CHIRPS_EA.nc CHIRPS_EA_allyear.nc

cdo -sellonlatbox,38.95,39.05,1.75,1.85 CHIRPS_EA_allyear.nc CHIRPS_point_A.nc
cdo -sellonlatbox,43.45,43.55,2.95,3.05 CHIRPS_EA_allyear.nc CHIRPS_point_B.nc
cdo -sellonlatbox,45.95,46.05,6.95,7.05 CHIRPS_EA_allyear.nc CHIRPS_point_C.nc
cdo -sellonlatbox,48.95,49.05,9.45,9.55 CHIRPS_EA_allyear.nc CHIRPS_point_D.nc

cdo fldmean CHIRPS_point_A.nc CHIRPS_point_A_fldmean.nc
cdo fldmean CHIRPS_point_B.nc CHIRPS_point_B_fldmean.nc
cdo fldmean CHIRPS_point_C.nc CHIRPS_point_C_fldmean.nc
cdo fldmean CHIRPS_point_D.nc CHIRPS_point_D_fldmean.nc

cdo ymonmean CHIRPS_point_A_fldmean.nc CHIRPS_climatology_A.nc
cdo ymonmean CHIRPS_point_B_fldmean.nc CHIRPS_climatology_B.nc
cdo ymonmean CHIRPS_point_C_fldmean.nc CHIRPS_climatology_C.nc
cdo ymonmean CHIRPS_point_D_fldmean.nc CHIRPS_climatology_D.nc
