#!/bin/bash -l

#Calculate temporal Coefficient of Variation (CV)

#for mon in mar apr may oct nov dec
#do

#cdo -timmean -selyear,1983/2013 CHIRPS_monthlyavg_${mon}.nc CHIRPS_19832013mean_monthlyavg_${mon}.nc
#cdo -timstd -selyear,1983/2013 CHIRPS_monthlyavg_${mon}.nc CHIRPS_19832013std_monthlyavg_${mon}.nc
#cdo -div CHIRPS_19832013std_monthlyavg_${mon}.nc CHIRPS_19832013mean_monthlyavg_${mon}.nc CHIRPS_19832013cv_monthlyavg_${mon}.nc

#cdo -fldstd CHIRPS_${mon}_regridded.nc CHIRPS_fldstd_${mon}.nc
#cdo -fldmean CHIRPS_${mon}_regridded.nc CHIRPS_fldmean_${mon}.nc
#cdo div CHIRPS_fldstd_${mon}.nc CHIRPS_fldmean_${mon}.nc CHIRPS_fldcv_${mon}.nc
#cdo regres -selyear,1983/2013 CHIRPS_fldcv_${mon}.nc CHIRPS_b_fldcv_${mon}.nc

#done

#for seas in longrains shortrains
#do

#cdo -fldstd CHIRPS_${seas}_regridded_2.nc CHIRPS_fldstd_${seas}.nc
#cdo -fldmean CHIRPS_${seas}_regridded_2.nc CHIRPS_fldmean_${seas}.nc
#cdo div CHIRPS_fldstd_${seas}.nc CHIRPS_fldmean_${seas}.nc CHIRPS_fldcv_${seas}.nc
#cdo regres -selyear,1983/2013 CHIRPS_fldcv_${seas}.nc CHIRPS_b_fldcv_${seas}.nc

#done

#cdo -yearstd -selmon,3/5 CHIRPS_pentads_EA.nc CHIRPS_seasonstd_lr.nc
#cdo div CHIRPS_seasonstd_lr.nc CHIRPS_seasonavg_lr.nc CHIRPS_seasoncv_lr.nc
#cdo -yearstd -selmon,10/12 CHIRPS_pentads_EA.nc CHIRPS_seasonstd_sr.nc
#cdo div CHIRPS_seasonstd_sr.nc CHIRPS_seasonavg_sr.nc CHIRPS_seasoncv_sr.nc

#cdo -yearstd -selmon,03 CHIRPS_pentads_EA.nc CHIRPS_monthlystd_mar.nc
#cdo div CHIRPS_monthlystd_mar.nc CHIRPS_monthlyavg_mar.nc CHIRPS_monthlycv_mar.nc
#cdo -yearstd -selmon,04 CHIRPS_pentads_EA.nc CHIRPS_monthlystd_apr.nc
#cdo div CHIRPS_monthlystd_apr.nc CHIRPS_monthlyavg_apr.nc CHIRPS_monthlycv_apr.nc
#cdo -yearstd -selmon,05 CHIRPS_pentads_EA.nc CHIRPS_monthlystd_may.nc
#cdo div CHIRPS_monthlystd_may.nc CHIRPS_monthlyavg_may.nc CHIRPS_monthlycv_may.nc
#cdo -yearstd -selmon,10 CHIRPS_pentads_EA.nc CHIRPS_monthlystd_oct.nc
#cdo div CHIRPS_monthlystd_oct.nc CHIRPS_monthlyavg_oct.nc CHIRPS_monthlycv_oct.nc
#cdo -yearstd -selmon,11 CHIRPS_pentads_EA.nc CHIRPS_monthlystd_nov.nc
#cdo div CHIRPS_monthlystd_nov.nc CHIRPS_monthlyavg_nov.nc CHIRPS_monthlycv_nov.nc
#cdo -yearstd -selmon,12 CHIRPS_pentads_EA.nc CHIRPS_monthlystd_dec.nc
#cdo div CHIRPS_monthlystd_dec.nc CHIRPS_monthlyavg_dec.nc CHIRPS_monthlycv_dec.nc

cdo -timmean -selmon,3/5 -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_mean_lr.nc
cdo -timstd -selmon,3/5 -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_std_lr.nc
cdo -add CHIRPS_mean_lr.nc CHIRPS_std_lr.nc CHIRPS_threshold_up_lr.nc
cdo -sub CHIRPS_mean_lr.nc CHIRPS_std_lr.nc CHIRPS_threshold_down_lr.nc
cdo -timmean -selmon,10/12 -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_mean_sr.nc
cdo -timstd -selmon,10/12 -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_std_sr.nc
cdo -add CHIRPS_mean_sr.nc CHIRPS_std_sr.nc CHIRPS_threshold_up_sr.nc
cdo -sub CHIRPS_mean_sr.nc CHIRPS_std_sr.nc CHIRPS_threshold_down_sr.nc

cdo ge -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_threshold_up_lr.nc CHIRPS_above_lr.nc
cdo ge -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_threshold_up_sr.nc CHIRPS_above_sr.nc

cdo le -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_threshold_down_lr.nc CHIRPS_below_lr.nc
cdo le -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_threshold_down_sr.nc CHIRPS_below_sr.nc

cdo -yearsum -selmon,3/5 CHIRPS_above_lr.nc CHIRPS_nr_above_lr.nc
cdo -yearsum -selmon,10/12 CHIRPS_above_sr.nc CHIRPS_nr_above_sr.nc
cdo -yearsum -selmon,3/5 CHIRPS_below_lr.nc CHIRPS_nr_below_lr.nc
cdo -yearsum -selmon,10/12 CHIRPS_below_sr.nc CHIRPS_nr_below_sr.nc

cdo -mul -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_above_lr.nc CHIRPS_pentads_above_lr.nc
cdo -mul -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_above_sr.nc CHIRPS_pentads_above_sr.nc
cdo -mul -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_below_lr.nc CHIRPS_pentads_below_lr.nc
cdo -mul -setctomiss,0 CHIRPS_pentads_EA.nc CHIRPS_below_sr.nc CHIRPS_pentads_below_sr.nc

cdo -yearsum -selmon,3/5 CHIRPS_pentads_above_lr.nc CHIRPS_above_lr.nc
cdo -yearsum -selmon,10/12 CHIRPS_pentads_above_sr.nc CHIRPS_above_sr.nc
cdo -yearsum -selmon,3/5 CHIRPS_pentads_below_lr.nc CHIRPS_below_lr.nc
cdo -yearsum -selmon,10/12 CHIRPS_pentads_below_sr.nc CHIRPS_below_sr.nc
