#!/bin/bash -l

#calculate sesonal extreme precipitiation

#for year in {2002..2018..1}
#do
#cdo sellonlatbox,32,56,-11,18 global_daily/chirps-v2.0.${year}.days_p05.nc CHIRPS_daily_annual_EA_${year}.nc
#cdo -selmon,3,4,5 CHIRPS_daily_annual_EA_${year}.nc CHIRPS_daily_MAM_EA_${year}.nc 
#cdo -selmon,6,7,8 CHIRPS_daily_annual_EA_${year}.nc CHIRPS_daily_JJA_EA_${year}.nc 
#cdo -selmon,10,11,12 CHIRPS_daily_annual_EA_${year}.nc CHIRPS_daily_OND_EA_${year}.nc 
#cdo -selmon,3 CHIRPS_daily_annual_EA_${year}.nc CHIRPS_daily_mar_EA_${year}.nc 
#cdo -selmon,4 CHIRPS_daily_annual_EA_${year}.nc CHIRPS_daily_apr_EA_${year}.nc 
#cdo -selmon,5 CHIRPS_daily_annual_EA_${year}.nc CHIRPS_daily_may_EA_${year}.nc
#cdo -selmon,10 CHIRPS_daily_annual_EA_${year}.nc CHIRPS_daily_oct_EA_${year}.nc 
#cdo -selmon,11 CHIRPS_daily_annual_EA_${year}.nc CHIRPS_daily_nov_EA_${year}.nc
#cdo -selmon,12 CHIRPS_daily_annual_EA_${year}.nc CHIRPS_daily_dec_EA_${year}.nc   

#done

#for mon in mar apr may oct nov dec #MAM JJA OND annual
#do

#cdo mergetime CHIRPS_daily_${mon}_EA_????.nc CHIRPS_daily_${mon}_EA.nc

#rm CHIRPS_daily_${mon}_EA_????.nc

#done

cdo -selmon,1 CHIRPS_daily_annual_EA.nc CHIRPS_daily_jan_EA.nc 
cdo -selmon,2 CHIRPS_daily_annual_EA.nc CHIRPS_daily_feb_EA.nc 
#cdo -selmon,3 CHIRPS_daily_annual_EA.nc CHIRPS_daily_mar_EA.nc 
#cdo -selmon,4 CHIRPS_daily_annual_EA.nc CHIRPS_daily_apr_EA.nc 
#cdo -selmon,5 CHIRPS_daily_annual_EA.nc CHIRPS_daily_may_EA.nc
cdo -selmon,6 CHIRPS_daily_annual_EA.nc CHIRPS_daily_jun_EA.nc
cdo -selmon,7 CHIRPS_daily_annual_EA.nc CHIRPS_daily_jul_EA.nc
cdo -selmon,8 CHIRPS_daily_annual_EA.nc CHIRPS_daily_aug_EA.nc
cdo -selmon,9 CHIRPS_daily_annual_EA.nc CHIRPS_daily_sep_EA.nc
#cdo -selmon,10 CHIRPS_daily_annual_EA.nc CHIRPS_daily_oct_EA.nc 
#cdo -selmon,11 CHIRPS_daily_annual_EA.nc CHIRPS_daily_nov_EA.nc
#cdo -selmon,12 CHIRPS_daily_annual_EA.nc CHIRPS_daily_dec_EA.nc   

#cdo setctomiss,0 CHIRPS_daily_annual_EA.nc CHIRPS_daily_annual_EA_0.nc

#cdo timmax CHIRPS_daily_annual_EA_0.nc CHIRPS_daily_annual_EA_0_max.nc
#cdo timmin CHIRPS_daily_annual_EA_0.nc CHIRPS_daily_annual_EA_0_min.nc

#cdo -timpctl,95 CHIRPS_daily_annual_EA_0.nc CHIRPS_daily_annual_EA_0_min.nc CHIRPS_daily_annual_EA_0_max.nc CHIRPS_daily_annual_EA_95pctl.nc
#cdo -timpctl,90 CHIRPS_daily_annual_EA_0.nc CHIRPS_daily_annual_EA_0_min.nc CHIRPS_daily_annual_EA_0_max.nc CHIRPS_daily_annual_EA_90pctl.nc
#cdo -timpctl,75 CHIRPS_daily_annual_EA_0.nc CHIRPS_daily_annual_EA_0_min.nc CHIRPS_daily_annual_EA_0_max.nc CHIRPS_daily_annual_EA_75pctl.nc

#rm CHIRPS_daily_annual_EA_0_max.nc
#rm CHIRPS_daily_annual_EA_0_min.nc

for mon in jan feb jun jul aug sep #mar apr may oct nov dec #MAM JJA OND annual
do

cdo -ge CHIRPS_daily_${mon}_EA.nc CHIRPS_daily_annual_EA_95pctl.nc CHIRPS_daily_annual_EA_95pctl_g.nc
cdo -ge CHIRPS_daily_${mon}_EA.nc CHIRPS_daily_annual_EA_90pctl.nc CHIRPS_daily_annual_EA_90pctl_g.nc
cdo -ge CHIRPS_daily_${mon}_EA.nc CHIRPS_daily_annual_EA_75pctl.nc CHIRPS_daily_annual_EA_75pctl_g.nc

cdo -ifthen CHIRPS_daily_annual_EA_95pctl_g.nc CHIRPS_daily_${mon}_EA.nc CHIRPS_ifthen_95.nc
cdo -ifthen CHIRPS_daily_annual_EA_90pctl_g.nc CHIRPS_daily_${mon}_EA.nc CHIRPS_ifthen_90.nc
cdo -ifthen CHIRPS_daily_annual_EA_75pctl_g.nc CHIRPS_daily_${mon}_EA.nc CHIRPS_ifthen_75.nc

cdo yearsum CHIRPS_ifthen_95.nc CHIRPS_above_95pctl_${mon}_EA.nc
cdo yearsum CHIRPS_ifthen_90.nc CHIRPS_above_90pctl_${mon}_EA.nc
cdo yearsum CHIRPS_ifthen_75.nc CHIRPS_above_75pctl_${mon}_EA.nc

rm CHIRPS_daily_annual_EA_??pctl_g.nc
rm CHIRPS_ifthen_??.nc

cdo -setctomiss,0 CHIRPS_daily_${mon}_EA.nc CHIRPS_daily_${mon}_EA_0.nc

cdo yearsum CHIRPS_daily_${mon}_EA_0.nc CHIRPS_above_0pctl_${mon}_EA.nc

cdo remapcon2,GRACE_grid_05_EA.txt CHIRPS_above_95pctl_${mon}_EA.nc CHIRPS_above_95pctl_${mon}_EA_GRACE.nc
cdo remapcon2,GRACE_grid_05_EA.txt CHIRPS_above_90pctl_${mon}_EA.nc CHIRPS_above_90pctl_${mon}_EA_GRACE.nc
cdo remapcon2,GRACE_grid_05_EA.txt CHIRPS_above_75pctl_${mon}_EA.nc CHIRPS_above_75pctl_${mon}_EA_GRACE.nc
cdo remapcon2,GRACE_grid_05_EA.txt CHIRPS_above_0pctl_${mon}_EA.nc CHIRPS_above_0pctl_${mon}_EA_GRACE.nc

done

