#!/bin/bash -l

#cdo remapcon2,../MSWEP2/grid_CHIRPS_05deg_GRACE.txt Final_GRACE_CSR.nc Final_GRACE_CSR_remapcon.nc

#cdo -ifthen ../MSWEP2/mswepFJSmask_lec30_05deg_africa.nc Final_GRACE_CSR_remapcon.nc Final_GRACE_CSR_newbimodal.nc

cdo remapcon2,../MSWEP2/grid_CHIRPS_05deg_GRACE.txt Final_GRACE_CSR_interpolated.nc Final_GRACE_CSR_interpolated_remapcon.nc

cdo -ifthen ../MSWEP2/mswepFJSmask_lec30_05deg_africa.nc Final_GRACE_CSR_interpolated_remapcon.nc Final_GRACE_CSR_interpolated_newbimodal.nc

for mon in 1 2 3 4 5 6 7 8 9 10 11 12 
do

cdo -selmon,$mon Final_GRACE_CSR_interpolated_newbimodal.nc Final_GRACE_CSR_newbimodal_$mon.nc
cdo fldmean Final_GRACE_CSR_newbimodal_$mon.nc Final_GRACE_CSR_newbimodal_${mon}_fldmean.nc

done

cdo fldmean Final_GRACE_CSR_interpolated_newbimodal.nc Final_GRACE_CSR_newbimodal__fldmean.nc

cdo sub -seltimestep,2/213 Final_GRACE_CSR_interpolated_newbimodal.nc -seltimestep,1/212 Final_GRACE_CSR_interpolated.nc Final_GRACE_CSR_interpolated_DeltaTWS.nc
cdo fldmean Final_GRACE_CSR_interpolated_DeltaTWS.nc Final_GRACE_CSR_newbimodal_DeltaTWS_fldmean.nc

cdo sub -seltimestep,1/17 Final_GRACE_CSR_newbimodal_2.nc -seltimestep,1/17 Final_GRACE_CSR_newbimodal_9.nc Final_GRACE_CSR_newbimodal_DeltaOND.nc
cdo sub -seltimestep,2/18 Final_GRACE_CSR_newbimodal_7.nc -seltimestep,1/17 Final_GRACE_CSR_newbimodal_2.nc Final_GRACE_CSR_newbimodal_DeltaMAM.nc

cdo fldmean Final_GRACE_CSR_newbimodal_DeltaOND.nc Final_GRACE_CSR_newbimodal_DeltaOND_fldmean.nc
cdo fldmean Final_GRACE_CSR_newbimodal_DeltaMAM.nc Final_GRACE_CSR_newbimodal_DeltaMAM_fldmean.nc
 
#cdo sub -seltimestep,2/213 Final_GRACE_CSR_newbimodal.nc -seltimestep,1/212  Final_GRACE_CSR_newbimodal.nc Final_GRACE_CSR_newbimodal_mondiff.nc
