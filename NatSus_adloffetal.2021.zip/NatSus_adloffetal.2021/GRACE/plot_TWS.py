#! /usr/lib/python2.7
# -*- coding: utf-8 -*-

import time
import sys
from netCDF4 import Dataset
import matplotlib as mpl
from matplotlib import pyplot as plt
import numpy as np
import csv
import mkt

### 		  ###
#   General input   #
		    #
startyear = 1983    #
endyear = 2016	    #
region = 'yes'	    #
		    #
###		  ###


def read_data(name):
#read in netcdf files and create data lists ###
	read_file='Final_GRACE_CSR_newbimodal_'+name+'_fldmean.nc'

	data = Dataset(read_file, 'r')
	#print data.variables
	prec_annual = data.variables['prec'][:]
	return prec_annual
	
def interpolate_gaps(inputs):
#interpolate missing months by linear combination of neighbouring data
	outputs = [np.nan for i in range(len(inputs))]

	for i in range(2,len(inputs)-2):
		if np.isnan(inputs[i]) and not np.isnan(inputs[i-1]) and not np.isnan(inputs[i+1]):
			outputs[i] = (float(inputs[i-1]) + float(inputs[i+1]))/2.
			
		elif np.isnan(inputs[i]) and np.isnan(inputs[i-1]) and not np.isnan(inputs[i-2]) and not np.isnan(inputs[i+1]):
			outputs[i] = (float(inputs[i+1])-float(inputs[i-2]))/3.*2.+float(inputs[i-2])
			
		elif np.isnan(inputs[i]) and np.isnan(inputs[i+1]) and not np.isnan(inputs[i-1]) and not np.isnan(inputs[i+2]):
			outputs[i] = (float(inputs[i+2])-float(inputs[i-1]))/3.+float(inputs[i-1])
	return outputs

### plot ###

def plot(inputs):

	cmap = mpl.cm.get_cmap('Spectral')
	labels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

	fig = plt.figure()
	ax = fig.add_subplot(111)
	for i in range(len(inputs)):
		
		if len(inputs[i]) == 18:
			p1 = ax.plot([i for i in range(2002,2020)], inputs[i][:,0], color=cmap(float(i)/len(inputs)), label=labels[i])
		elif len(inputs[i]) == 17:
			p1 = ax.plot([i for i in range(2003,2020)], inputs[i][:,0], color=cmap(float(i)/len(inputs)), label=labels[i])
	ax.set_xlabel('Year',fontsize=18)
	ax.set_ylabel('TWS',fontsize=18)
	ax.set_xlim([2001.5,2020])
	plt.locator_params(axis='x', nbins=12)
	ax.grid()
	ax.legend(ncol=6,loc=3, bbox_to_anchor=(-0.05,1.01))

	plt.show()
#	plt.savefig(filename)

def plot_seasons(inputs):

	colors = ['royalblue','peru']
	labels = ['OND','MAM']

	fig = plt.figure()
	ax = fig.add_subplot(111)
	for i in range(len(inputs)):
		if i == 0:
			p1 = ax.plot([i for i in range(2002,2019)], inputs[i][:,0], color=colors[i], label=labels[i])
		elif i == 1:
			p1 = ax.plot([i for i in range(2003,2020)], inputs[i][:,0], color=colors[i], label=labels[i])
	ax.set_xlabel('Year',fontsize=18)
	ax.set_ylabel('$\Delta$TWS',fontsize=18)
	ax.set_xlim([2001.5,2020])
	plt.locator_params(axis='x', nbins=12)
	ax.grid()
	ax.legend(loc=4)

	plt.show()
#	plt.savefig(filename)

def plot_deltamons(inputs):

	fig = plt.figure()
	ax = fig.add_subplot(111)
	p1 = ax.plot([i for i in range(len(inputs))], inputs[:,0], color='royalblue')
	ax.set_xlabel('Year',fontsize=18)
	ax.set_ylabel('$\Delta$TWS',fontsize=18)
	#ax.set_xlim([2001.5,2020])
	plt.locator_params(axis='x', nbins=12)
	ax.grid()
	ax.legend(loc=4)

	plt.show()
#	plt.savefig(filename)

def plot_timeseries_seasons(inputs):

	colors = ['royalblue','peru']
	labels = ['OND','MAM']

	fig = plt.figure()
	ax = fig.add_subplot(111)
	for i in range(len(inputs)):
		if i == 0:
			p1 = ax.plot([i for i in range(len(inputs[i]))], inputs[i], color=colors[i], label=labels[i])
		elif i == 1:
			p1 = ax.plot([i+1 for i in range(len(inputs[i]))], inputs[i], color=colors[i], label=labels[i])
	ax.set_xlabel('Year',fontsize=18)
	ax.set_ylabel('TWS',fontsize=18)
	ax.set_ylim([-60,60])
#	ax.set_xticks([8,20,32,44,56,68,80,92,104,116,128,140,152,164,176,188,200,212])
	ax.set_xticks([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16])
	ax.set_xticklabels(['',2003,'',2005,'',2007,'',2009,'',2011,'',2013,'',2015,'',2017,''])
	ax.grid()

	plt.show()
#	plt.savefig(filename)

inputs = []

#for i in range(1,13):
#	inputs.append(read_data(str(i)))	
#plot(inputs)

#for i in ['DeltaOND','DeltaMAM']:
#	inputs.append(read_data(i))
#plot_seasons(inputs)

inputs = read_data('')
inputs_1 = interpolate_gaps(inputs)
Delta_OND = []
Delta_MAM = []

inputs_2 = [np.nan for i in range(len(inputs))]
for i in range(len(inputs_1)):
	 if not np.isnan(inputs[i]):
	 	inputs_2[i] = inputs[i]
	 if not np.isnan(inputs_1[i]):
	 	inputs_2[i] = inputs_1[i]

for i in range(17):
	Delta_OND.append(inputs_2[11+12*i]-inputs_2[5+12*i])
	Delta_MAM.append(inputs_2[16+12*i]-inputs_2[11+12*i])
#plot_timeseries(inputs)
plot_timeseries_seasons([Delta_OND,Delta_MAM])	
