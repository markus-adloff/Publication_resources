#! /usr/lib/python2.7
# -*- coding: utf-8 -*-

import time
import sys
from netCDF4 import Dataset
import matplotlib as mpl
from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib import cm
from PIL import Image
from scipy.stats import ttest_ind,t
import scipy.stats as st
import numpy as np
import csv
import mkt

### 		  ###
#   General input   #
		    #
startyear = 2002    #
endyear = 2014	    #
region = 'yes'	    #
		    #
###		  ###


#read in netcdf files and create data lists ###

#read_file='MSWEP_GHA_OND_05deg_lsm.nc'
#read_file='MSWEP_above_0pct_annual_05deg_lsm.nc'
read_file='MSWEP2_EA_MAM_yearsum_lsm.nc'

data = Dataset(read_file, 'r')
print data.variables
lons = data.variables['lat'][:]
lats = data.variables['lon'][:]
prec_annual = data.variables['precipitation'][:,:,:] #time,lat,lon

years = np.arange(startyear,endyear+1)

read_file='mswepFJSmask_lec30_05deg_africa_zeros.nc'

data = Dataset(read_file, 'r')
#print data.variables
land_sea_mask = data.variables['fld'][:,:] #lat,lon

### find lon and lat ###

if region == 'yes':
	for i in range(len(lats)-1):
		if lats[i] <= 34 and lats[i+1] > 34:
			latmin = i
		elif lats[i] <= 52. and lats[i+1] > 52.:
			latmax = i
	for i in range(len(lons)-1):
		if lons[i] > -5. and lons[i+1] <= -5.:
			lonmax = i
		elif lons[i] > 13. and lons[i+1] <= 13. :
			lonmin = i

else:
	lonmin,lonmax,latmin,latmax = 0,len(lons),0,len(lats)
	print lats[latmin:latmax]
### calculate linear trend ###
def trending(prec_annual,idx_years,idx):

	### test if actual prec_annual and prec_annual_guess, calculated via the regression function, are the same population at a significant level ###
	print lonmax, latmax
	print len(prec_annual),len(prec_annual[0]),len(prec_annual[0][0])

	lin_trend_a = [[0 for x in range(lonmin,lonmax)] for y in range(latmin,latmax)]
	lin_trend_b = [[np.nan for x in range(lonmin,lonmax)] for y in range(latmin,latmax)]
	T_zero = [[0. for x in range(lonmin,lonmax)] for y in range(latmin,latmax)]
	p_value = [[np.nan for x in range(lonmin,lonmax)] for y in range(latmin,latmax)]


	for lat in range(latmax-latmin):
		for lon in range(lonmax-lonmin):
			data = []
			time = []
#			print lat,lon
			for x in idx:
				if np.isfinite(prec_annual[x][lonmin+lon][latmin+lat]):
					data.append(prec_annual[x][lonmin+lon][latmin+lat])
					time.append(idx_years[x-offset])
			a,lin_trend_a[lat][lon],lin_trend_b[lat][lon],p_value[lat][lon] = mkt.test(np.asarray(time),np.asarray(data),0.001,0.95,'upordown')
#			a,lin_trend_a[lat][lon],lin_trend_b[lat][lon],p_value[lat][lon] = mkt.test(np.asarray(idx_years),np.asarray([prec_annual[x][latmin+lat][lonmin+lon] for x in idx]),0.001,0.95,'upordown')
			T_zero[lat][lon] = st.norm.ppf(p_value[lat][lon])
			
			#lin_trend_a[lat][lon],lin_trend_b[lat][lon] = np.polyfit(idx_years,[prec_annual[x][latmin+lat][lonmin+lon] for x in idx],1)
			#s_e = np.sqrt((np.nansum((np.asarray([prec_annual[x][latmin+lat][lonmin+lon] for x in idx]) - np.asarray([lin_trend_a[lat][lon]*x + lin_trend_b[lat][lon] for x in idx_years]))**2)/(len(idx_years)-2.))/(np.sum((np.asarray(idx_years) - np.mean(idx_years))**2)))
			#T_zero[lat][lon] = (lin_trend_a[lat][lon] - 0.)/s_e

	lin_trendm = np.ma.masked_inside(T_zero,-t.ppf(0.95,df=len(idx_years)-2),t.ppf(0.95,df=len(idx_years)-2))
	
	return lin_trend_a, lin_trend_b, T_zero, p_value


### plot ###

def plot_local_trend(data,trends_a,trends_b,time,caption,lat,lon):

	fig = plt.figure()
	ax = fig.add_subplot(111)
	p1 = ax.scatter(time, [data[x][latmin+lat][lonmin+lon] for x in range(len(years))], color='gray', label='data')
	p2, = ax.plot(time,[trends_a[lat][lon]*x + trends_b[lat][lon] for x in years], color='black', label='regression')
	ax.set_xlabel('month',fontsize=18)
	ax.set_ylabel('precipitation sum [mm]',fontsize=18)
	ax.grid()
	ax.legend(loc=2)

	plt.show()
#	plt.savefig(filename)

def plot_2D(data,significance,caption,lon,lat,i):

	cmap= cm.BrBG
	#bounds = np.linspace(-5,5,11) 
	bounds = np.linspace(-20,20,9) 
	norm = mpl.colors.BoundaryNorm(bounds, cmap.N)

	fig = plt.figure(figsize=(5,7))
	m = Basemap(projection='merc', lat_0=0, lon_0=0,\
	    urcrnrlat=lon[1],llcrnrlat=lon[len(lon)-2],\
            llcrnrlon=lat[2],urcrnrlon=lat[len(lat)-1],resolution='l')
#	lat = list(-1*np.asarray(lat)+6.5)
	x_mesh,y_mesh = np.meshgrid(lat,lon,indexing='ij')
	x,y = m(x_mesh,y_mesh)
	v,w = m(33,0)
	m.drawcountries()
	m.drawcoastlines()
	p1 = m.pcolormesh(x,y,data,cmap=cmap,norm=norm,vmin=-20,vmax=20)
	p2 = plt.contour(x,y,land_sea_mask[lonmin:lonmax,latmin:latmax].T,corner_mask=True,cmap='Greys')
#	p2 = m.pcolor(x,y,significance, hatch='//', alpha=0.)
	for j, i in np.column_stack(np.where(np.ma.getmask(significance) == False)):
		x,y = m([lat[j],lat[j]+0.5,lat[j]+0.5,lat[j]],[lon[i]-0.5,lon[i]-0.5,lon[i],lon[i]])
		xy = zip(x,y)
      		plt.gca().add_patch(Polygon( xy, edgecolor='gray',fill=False, alpha=1.0 ))
	cb = plt.colorbar(p1)
	cb.ax.set_yticklabels(cb.ax.get_yticklabels(),rotation=90,fontsize=15)
	cb.set_label(label = 'Rainfall trend [mm/yr]',fontsize=18)
#	m.set_ylim([lon[0],lon[len(lon)-1]])
#	m.set_xlim([lat[0],lat[len(lat)-1]])
#	m.set_xlabel('lat', fontsize=18)
#	plt.setp( m.yaxis.get_majorticklabels(), rotation=90 )
#	m.set_ylabel('lon', fontsize=18)
#	plt.setp( m.xaxis.get_majorticklabels(), rotation=90 )

	plt.show()
#	filename="trends_"+str(startyear)+"-"+str(endyear)+"_annualprec_GPCC"+str(i)+".png"
#	plt.savefig(filename)

def writing_to_netcdf(data_to_write,filename,lon,lat):

	write_file='MSWEP_monthly_'+filename+'.nc'

	dataset = Dataset(write_file, 'w',format='NETCDF3_CLASSIC')
	lo = dataset.createDimension('lon', len(lon)) 
	la = dataset.createDimension('lat', len(lat))
	tim = dataset.createDimension('time', 1)

	longitudes = dataset.createVariable('lon', np.dtype('float32'), ('lon',))
	latitudes = dataset.createVariable('lat', np.dtype('float32'), ('lat',))
	times = dataset.createVariable('time', np.dtype('float32'), ('time',))
	the_data = dataset.createVariable('prec', np.dtype('float32'), ('lat','lon'), fill_value = -9999) 
	
	longitudes[:] = lon
	latitudes[:] = lat
	times[0] = 1.
	the_data[:,:] = np.nan_to_num(data_to_write)

	longitudes.units = 'degrees_east'
	latitudes.units = 'degrees_north'
	times.units = 'year+dekade'
	the_data.units = 'mm'

	dataset.history = 'Created ' + time.ctime(time.time())

	dataset.close()
	
def multitest_significance(T_zero,q,df):

	all_sigs = np.asarray(T_zero).flatten()
	print all_sigs
	print'hi'
	all_sigs[all_sigs == 0.5] = np.nan
	all_sigs = all_sigs[np.logical_not(np.isnan(all_sigs))]
	k=np.sort(all_sigs)[0]
	for i in range(len(all_sigs)-1):
		if np.sort(all_sigs)[i] <= q*i/len(all_sigs) and np.sort(all_sigs)[i+1] > q*i/len(all_sigs):
			if np.sort(all_sigs)[i] > k:
				k = np.sort(all_sigs)[i]
	T_zero_new = np.ma.masked_equal(T_zero,0.5)
	T_zero_new3 = np.ma.masked_less_equal(T_zero_new,k)
	T_zero_new3[T_zero_new3 == 0.] = np.nan
	T_zero_new4 = np.ma.masked_invalid(T_zero_new3)
	return T_zero_new4
	

#lin_trend_a = np.asarray(lin_trend_a).T
#lin_trendm = np.swapaxes(lin_trendm,0,1)
#print len(lin_trend_a), len(lin_trend_a[0])
#plot_2D(np.asarray(lin_trend_a).T,np.swapaxes(lin_trendm,0,1),'precipitation trends [mm]',lons[lonmin:lonmax],lats[latmax:latmin])

#trends over moving 30-year windows
#for i in range(1979,2012-30):
#	years = np.arange(i,i+30.+1)
#	startyear = i
#	endyear = i+30
#	offset = i - 1979
#	idx = [x for x in range(offset,offset+31)]
#	print years, idx
#	lin_trend_a,lin_trend_b,lin_trendm = trending(prec_annual,years,idx)
#	plot_2D(np.asarray(lin_trend_a).T,np.swapaxes(lin_trendm,0,1),'precipitation trends [mm]',lons[lonmin:lonmax],lats[latmax:latmin],i)
	
#robust trends: randomyears
startyear = 2003
endyear = 2016
years = np.arange(startyear,endyear+1)
offset = startyear - 1979 #2002
#lin_trendm_int = [[np.nan for x in range(lonmin,lonmax)] for y in range(latmax,latmin)]
#for i in years:
#	j = list(years).index(i)
#	idx_years = list(np.copy(years))
#	del idx_years[j]
#	idx = [offset+x for x in range(len(years)) if (x != j)]
#	lin_trend_a,lin_trend_b,lin_trendm,T_zero = trending(prec_annual,np.asarray(idx_years),idx)
#	plot_2D(np.asarray(lin_trend_a).T,np.swapaxes(lin_trendm,0,1),str(i),lons[lonmin:lonmax],-np.asarray(lats))
#	for k in range(len(lin_trendm_int)):
#		lin_trendm_int[k] = [np.nan if lin_trendm.mask[k][x] == True else lin_trendm_int[k][x] for x in range(len(lin_trendm[k]))]  
#lin_trendm_all = np.ma.masked_invalid(lin_trendm_int)
lin_trend_a,lin_trend_b,lin_trendm,T_zero = trending(prec_annual,years,[offset+x for x in range(len(years))])
lin_trend_a = np.ma.masked_invalid(lin_trend_a)
#print T_zero
T_zero_new = multitest_significance(T_zero,0.1,len(years)-2)

print lin_trend_a

#for lat,lon in [(10,10), (20,20), (40,40), (50,15)]:
#	plot_local_trend(prec_annual*1000.,lin_trend_a,lin_trend_b,years,'yearly precipitation',lat,lon)

#writing_to_netcdf(np.swapaxes(lin_trend_a,0,1),'OND_regridded_'+str(startyear)+str(endyear),lats[latmin:latmax],lons[lonmin:lonmax])
#writing_to_netcdf(np.swapaxes(T_zero_new,0,1),'MAM_regridded_multisig_',lats[latmin:latmax],lons[lonmin:lonmax])
	
#print lin_trendm_all
#print lats[latmin:latmax]
plot_2D(lin_trend_a,T_zero_new,str(2002),lons[lonmin:lonmax],lats[latmin:latmax],2002)
