#!/bin/bash -l

cdo yearsum -selmon,2,3,4 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_MAM.nc
cdo yearsum -selmon,9,10,11 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_OND.nc

#extract extreme rainfall thresholds
cdo setctomiss,0 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_0.nc
#cdo -gec,5 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_1.nc
#cdo ifthen MSWEP_GHA_1.nc pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_0.nc
cdo yearsum -selmon,2,3,4 MSWEP_GHA_0.nc MSWEP_GHA_MAM_0.nc
cdo yearsum -selmon,9,10,11 MSWEP_GHA_0.nc MSWEP_GHA_OND_0.nc
cdo timmax MSWEP_GHA_0.nc MSWEP_GHA_0_max.nc
cdo timmin MSWEP_GHA_0.nc MSWEP_GHA_0_min.nc

cdo timpctl,80 MSWEP_GHA_0.nc MSWEP_GHA_0_min.nc MSWEP_GHA_0_max.nc MSWEP_GHA_0_80pct.nc
cdo timpctl,90 MSWEP_GHA_0.nc MSWEP_GHA_0_min.nc MSWEP_GHA_0_max.nc MSWEP_GHA_0_90pct.nc
cdo timpctl,95 MSWEP_GHA_0.nc MSWEP_GHA_0_min.nc MSWEP_GHA_0_max.nc MSWEP_GHA_0_95pct.nc
cdo timpctl,99 MSWEP_GHA_0.nc MSWEP_GHA_0_min.nc MSWEP_GHA_0_max.nc MSWEP_GHA_0_99pct.nc

cdo remapcon2,../CHIRPS/grid_CHIRPS_05deg.txt MSWEP_GHA_0.nc MSWEP_GHA_0_05deg.nc
cdo timmax MSWEP_GHA_0_05deg.nc MSWEP_GHA_0_05deg_max.nc
cdo timmin MSWEP_GHA_0_05deg.nc MSWEP_GHA_0_05deg_min.nc
cdo timpctl,95 MSWEP_GHA_0_05deg.nc MSWEP_GHA_0_05deg_min.nc MSWEP_GHA_0_05deg_max.nc MSWEP_GHA_0_05deg_95pct.nc

#apply thresholds

for mon in MAM OND
do

cdo -ge MSWEP_GHA_${mon}.nc MSWEP_GHA_0_80pct.nc  MSWEP_GHA_0_80pct_g.nc
cdo -ge MSWEP_GHA_${mon}.nc MSWEP_GHA_0_90pct.nc MSWEP_GHA_0_90pct_g.nc
cdo -ge MSWEP_GHA_${mon}.nc MSWEP_GHA_0_95pct.nc MSWEP_GHA_0_95pct_g.nc
cdo -ge MSWEP_GHA_${mon}.nc MSWEP_GHA_0_99pct.nc MSWEP_GHA_0_99pct_g.nc

cdo -ifthen MSWEP_GHA_0_80pct_g.nc MSWEP_GHA_${mon}.nc MSWEP_ifthen_80.nc
cdo -ifthen MSWEP_GHA_0_90pct_g.nc MSWEP_GHA_${mon}.nc MSWEP_ifthen_90.nc
cdo -ifthen MSWEP_GHA_0_95pct_g.nc MSWEP_GHA_${mon}.nc MSWEP_ifthen_95.nc
cdo -ifthen MSWEP_GHA_0_99pct_g.nc MSWEP_GHA_${mon}.nc MSWEP_ifthen_99.nc

cdo yearsum MSWEP_ifthen_80.nc MSWEP_above_80pct_${mon}_nan.nc
cdo yearsum MSWEP_ifthen_90.nc MSWEP_above_90pct_${mon}_nan.nc
cdo yearsum MSWEP_ifthen_95.nc MSWEP_above_95pct_${mon}_nan.nc
cdo yearsum MSWEP_ifthen_99.nc MSWEP_above_99pct_${mon}_nan.nc

cdo setmisstoc,0 MSWEP_above_80pct_${mon}_nan.nc MSWEP_above_80pct_${mon}.nc
cdo setmisstoc,0 MSWEP_above_90pct_${mon}_nan.nc MSWEP_above_90pct_${mon}.nc
cdo setmisstoc,0 MSWEP_above_95pct_${mon}_nan.nc MSWEP_above_95pct_${mon}.nc
cdo setmisstoc,0 MSWEP_above_99pct_${mon}_nan.nc MSWEP_above_99pct_${mon}.nc


rm MSWEP_GHA_0_??pct_g.nc
rm MSWEP_ifthen_??.nc

cdo yearsum MSWEP_GHA_${mon}.nc MSWEP_above_0pct_${mon}.nc

cdo ifthen mswepFJSmask_lec30_invertlat.nc MSWEP_above_80pct_${mon}.nc MSWEP_above_80pct_${mon}_newbimodal.nc
cdo ifthen mswepFJSmask_lec30_invertlat.nc MSWEP_above_90pct_${mon}.nc MSWEP_above_90pct_${mon}_newbimodal.nc
cdo ifthen mswepFJSmask_lec30_invertlat.nc MSWEP_above_95pct_${mon}.nc MSWEP_above_95pct_${mon}_newbimodal.nc
cdo ifthen mswepFJSmask_lec30_invertlat.nc MSWEP_above_99pct_${mon}.nc MSWEP_above_99pct_${mon}_newbimodal.nc
cdo ifthen mswepFJSmask_lec30_invertlat.nc MSWEP_above_0pct_${mon}.nc MSWEP_above_0pct_${mon}_newbimodal.nc

cdo sellonlatbox,32.05,58.05,-14.95,11.85 MSWEP_above_80pct_${mon}_newbimodal.nc MSWEP_above_80pct_${mon}_newbimodal_africa.nc
cdo sellonlatbox,32.05,58.05,-14.95,11.85 MSWEP_above_90pct_${mon}_newbimodal.nc MSWEP_above_90pct_${mon}_newbimodal_africa.nc
cdo sellonlatbox,32.05,58.05,-14.95,11.85 MSWEP_above_95pct_${mon}_newbimodal.nc MSWEP_above_95pct_${mon}_newbimodal_africa.nc
cdo sellonlatbox,32.05,58.05,-14.95,11.85 MSWEP_above_99pct_${mon}_newbimodal.nc MSWEP_above_99pct_${mon}_newbimodal_africa.nc
cdo sellonlatbox,32.05,58.05,-14.95,11.85 MSWEP_above_0pct_${mon}_newbimodal.nc MSWEP_above_0pct_${mon}_newbimodal_africa.nc

cdo fldmean MSWEP_above_80pct_${mon}_newbimodal_africa.nc MSWEP_above_80pct_${mon}_newbimodal_africa_fldmean.nc
cdo fldmean MSWEP_above_90pct_${mon}_newbimodal_africa.nc MSWEP_above_90pct_${mon}_newbimodal_africa_fldmean.nc
cdo fldmean MSWEP_above_95pct_${mon}_newbimodal_africa.nc MSWEP_above_95pct_${mon}_newbimodal_africa_fldmean.nc
cdo fldmean MSWEP_above_99pct_${mon}_newbimodal_africa.nc MSWEP_above_99pct_${mon}_newbimodal_africa_fldmean.nc
cdo fldmean MSWEP_above_0pct_${mon}_newbimodal_africa.nc MSWEP_above_0pct_${mon}_newbimodal_africa_fldmean.nc

cdo fldmean -sellonlatbox,38.95,39.05,1.75,1.85 MSWEP_above_0pct_${mon}_newbimodal_africa.nc MSWEP_above_0pct_${mon}_newbimodal_A.nc 
cdo fldmean -sellonlatbox,43.45,43.55,2.95,3.05 MSWEP_above_0pct_${mon}_newbimodal_africa.nc MSWEP_above_0pct_${mon}_newbimodal_B.nc
cdo fldmean -sellonlatbox,45.95,46.05,6.95,7.05 MSWEP_above_0pct_${mon}_newbimodal_africa.nc MSWEP_above_0pct_${mon}_newbimodal_C.nc
cdo fldmean -sellonlatbox,48.95,49.05,9.45,9.55 MSWEP_above_0pct_${mon}_newbimodal_africa.nc MSWEP_above_0pct_${mon}_newbimodal_D.nc

cdo fldmean -sellonlatbox,38.95,39.05,1.75,1.85 MSWEP_above_90pct_${mon}_newbimodal_africa.nc MSWEP_above_90pct_${mon}_newbimodal_A.nc 
cdo fldmean -sellonlatbox,43.45,43.55,2.95,3.05 MSWEP_above_90pct_${mon}_newbimodal_africa.nc MSWEP_above_90pct_${mon}_newbimodal_B.nc
cdo fldmean -sellonlatbox,45.95,46.05,6.95,7.05 MSWEP_above_90pct_${mon}_newbimodal_africa.nc MSWEP_above_90pct_${mon}_newbimodal_C.nc
cdo fldmean -sellonlatbox,48.95,49.05,9.45,9.55 MSWEP_above_90pct_${mon}_newbimodal_africa.nc MSWEP_above_90pct_${mon}_newbimodal_D.nc

cdo fldmean -sellonlatbox,38.95,39.05,1.75,1.85 MSWEP_above_95pct_${mon}_newbimodal_africa.nc MSWEP_above_95pct_${mon}_newbimodal_A.nc 
cdo fldmean -sellonlatbox,43.45,43.55,2.95,3.05 MSWEP_above_95pct_${mon}_newbimodal_africa.nc MSWEP_above_95pct_${mon}_newbimodal_B.nc
cdo fldmean -sellonlatbox,45.95,46.05,6.95,7.05 MSWEP_above_95pct_${mon}_newbimodal_africa.nc MSWEP_above_95pct_${mon}_newbimodal_C.nc
cdo fldmean -sellonlatbox,48.95,49.05,9.45,9.55 MSWEP_above_95pct_${mon}_newbimodal_africa.nc MSWEP_above_95pct_${mon}_newbimodal_D.nc

cdo fldmean -sellonlatbox,38.95,39.05,1.75,1.85 MSWEP_above_99pct_${mon}_newbimodal_africa.nc MSWEP_above_99pct_${mon}_newbimodal_A.nc 
cdo fldmean -sellonlatbox,43.45,43.55,2.95,3.05 MSWEP_above_99pct_${mon}_newbimodal_africa.nc MSWEP_above_99pct_${mon}_newbimodal_B.nc
cdo fldmean -sellonlatbox,45.95,46.05,6.95,7.05 MSWEP_above_99pct_${mon}_newbimodal_africa.nc MSWEP_above_99pct_${mon}_newbimodal_C.nc
cdo fldmean -sellonlatbox,48.95,49.05,9.45,9.55 MSWEP_above_99pct_${mon}_newbimodal_africa.nc MSWEP_above_99pct_${mon}_newbimodal_D.nc

cdo remapcon2,../CHIRPS/grid_CHIRPS_05deg.txt MSWEP_GHA_${mon}.nc MSWEP_GHA_${mon}_05deg.nc
cdo -ge MSWEP_GHA_${mon}_05deg.nc MSWEP_GHA_0_05deg_95pct.nc MSWEP_GHA_0_05deg_95pct_g.nc
cdo -ifthen MSWEP_GHA_0_05deg_95pct_g.nc MSWEP_GHA_${mon}_05deg.nc MSWEP_ifthen_95_05deg.nc
cdo yearsum MSWEP_ifthen_95_05deg.nc MSWEP_above_95pct_${mon}_05deg.nc
cdo setmisstoc,0 MSWEP_above_95pct_${mon}_05deg_nan.nc MSWEP_above_95pct_${mon}_05deg.nc
cdo ifthen mswepFJSmask_lec30_05deg_africa_nan.nc MSWEP_above_95pct_${mon}_05deg.nc MSWEP_above_95pct_${mon}_newbimodal_africa_05deg.nc
cdo fldmean MSWEP_above_95pct_${mon}_newbimodal_africa_05deg.nc MSWEP_above_95pct_${mon}_newbimodal_africa_05deg_fldmean.nc

cdo ifthen mswepFJSforMask_invertlat.nc MSWEP_above_0pct_${mon}.nc MSWEP_${mon}_lsm.nc
cdo sellonlatbox,32,56,-11,18 MSWEP_${mon}_lsm.nc MSWEP_${mon}_lsm_EA.nc
cdo remapcon2,grid_CHIRPS_05deg_GRACE.txt MSWEP_GHA_${mon}.nc MSWEP_above_0pct_${mon}_05deg.nc
cdo ifthen CHIRPS_pentads_MAM_GRACE_1990.nc MSWEP_above_0pct_${mon}_05deg.nc MSWEP_above_0pct_${mon}_05deg_lsm.nc


done

###point climatology

#cdo -sellonlatbox,38.95,39.05,1.75,1.85 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_point_A.nc
#cdo -sellonlatbox,43.45,43.55,2.95,3.05 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_point_B.nc
#cdo -sellonlatbox,45.95,46.05,6.95,7.05 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_point_C.nc
#cdo -sellonlatbox,48.95,49.05,9.45,9.55 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_point_D.nc

#cdo monsum MSWEP_GHA_point_A.nc MSWEP_GHA_point_A_monsum.nc
#cdo monsum MSWEP_GHA_point_B.nc MSWEP_GHA_point_B_monsum.nc
#cdo monsum MSWEP_GHA_point_C.nc MSWEP_GHA_point_C_monsum.nc
#cdo monsum MSWEP_GHA_point_D.nc MSWEP_GHA_point_D_monsum.nc

#cdo fldmean MSWEP_GHA_point_A_monsum.nc MSWEP_GHA_point_A_fldmean.nc
#cdo fldmean MSWEP_GHA_point_B_monsum.nc MSWEP_GHA_point_B_fldmean.nc
#cdo fldmean MSWEP_GHA_point_C_monsum.nc MSWEP_GHA_point_C_fldmean.nc
#cdo fldmean MSWEP_GHA_point_D_monsum.nc MSWEP_GHA_point_D_fldmean.nc

#cdo ymonmean MSWEP_GHA_point_A_fldmean.nc MSWEP_GHA_climatology_A.nc
#cdo ymonmean MSWEP_GHA_point_B_fldmean.nc MSWEP_GHA_climatology_B.nc
#cdo ymonmean MSWEP_GHA_point_C_fldmean.nc MSWEP_GHA_climatology_C.nc
#cdo ymonmean MSWEP_GHA_point_D_fldmean.nc MSWEP_GHA_climatology_D.nc
