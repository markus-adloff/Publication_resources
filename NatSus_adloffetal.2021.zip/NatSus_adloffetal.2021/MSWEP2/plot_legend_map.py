#! /usr/lib/python2.7
# -*- coding: utf-8 -*-

import time
import sys
from netCDF4 import Dataset
import matplotlib as mpl
from mpl_toolkits.basemap import Basemap
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib import cm
from PIL import Image
from scipy.stats import ttest_ind,t
import scipy.stats as st
import numpy as np
import csv
import mkt

### 		  ###
#   General input   #
		    #
startyear = 2002    #
endyear = 2014	    #
region = 'yes'	    #
		    #
###		  ###


#read in netcdf files and create data lists ###

read_file='MSWEP_GHA_mar_05deg_lsm.nc'
#read_file='MSWEP2_EA_MAM_yearsum_lsm.nc'

data = Dataset(read_file, 'r')
lons = data.variables['lat'][:]
lats = data.variables['lon'][:]
prec_annual = data.variables['precipitation'][:,:,:] #time,lat,lon

years = np.arange(startyear,endyear+1)

read_file='mswepFJSmask_lec30_05deg_africa_zeros.nc'

data = Dataset(read_file, 'r')
#print data.variables
land_sea_mask = data.variables['fld'][:,:] #lat,lon

### find lon and lat ###

if region == 'yes':
	for i in range(len(lats)-1):
		if lats[i] <= 34 and lats[i+1] > 34:
			latmin = i
		elif lats[i] <= 52. and lats[i+1] > 52.:
			latmax = i
	for i in range(len(lons)-1):
		if lons[i] > -5. and lons[i+1] <= -5.:
			lonmax = i
		elif lons[i] > 13. and lons[i+1] <= 13. :
			lonmin = i
			
else:
	lonmin,lonmax,latmin,latmax = 0,len(lons),0,len(lats)
	print(lats[latmin:latmax])

def plot_2D(caption,lon,lat,i):

	lats = [1.8,3.,7.0,9.5]
	lons = [39.,43.5,46,49.]
	colors = ('midnightblue','firebrick','peru','gray')
	markers = ['s','D','^','o']

	m = Basemap(projection='merc', lat_0=0, lon_0=0,\
	    urcrnrlat=lon[1],llcrnrlat=lon[len(lon)-2],\
            llcrnrlon=lat[2],urcrnrlon=lat[len(lat)-1],resolution='l')
#	lat = list(-1*np.asarray(lat)+6.5)
	x_mesh,y_mesh = np.meshgrid(lat,lon,indexing='ij')
	x,y = m(x_mesh,y_mesh)
	v,w = m(33,0)
	m.drawmapboundary(fill_color='lightsteelblue')
	m.fillcontinents(color='white')
	m.drawcountries()
	m.drawcoastlines()
	m.drawparallels([-5,0,5,10],labels=[True,False,False,False],fontsize=15)
	m.drawmeridians([35,40,45,50],labels=[False,False,False,True],fontsize=15)
	p2 = plt.contour(x,y,land_sea_mask[lonmin:lonmax,latmin:latmax].T,corner_mask=True,cmap='Greys')
	x,y = m(lons,lats)
	for i in range(len(lats)):
		m.scatter([x[i],],[y[i],],marker=markers[i],facecolor=colors[i],linewidth='12',zorder=10)

	plt.show()
#	filename="trends_"+str(startyear)+"-"+str(endyear)+"_annualprec_GPCC"+str(i)+".png"
#	#plt.savefig(filename)

plot_2D(str(2002),lons[lonmin:lonmax],lats[latmin:latmax],2002)
