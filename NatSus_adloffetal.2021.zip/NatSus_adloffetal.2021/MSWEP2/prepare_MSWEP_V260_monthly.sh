#!/bin/bash -l

cdo yearsum -selmon,2 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_mar.nc
cdo yearsum -selmon,3 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_apr.nc
cdo yearsum -selmon,4 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_may.nc
cdo yearsum -selmon,9 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_oct.nc
cdo yearsum -selmon,10 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_nov.nc
cdo yearsum -selmon,11 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_dec.nc
cdo yearsum -selmon,2,3,4 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_MAM.nc
cdo yearsum -selmon,9,10,11 pr_1m_MSWEP_V260_GHA_197901-201912.nc MSWEP_GHA_OND.nc

cdo remapcon2,../CHIRPS/grid_CHIRPS_05deg.txt MSWEP_GHA_mar.nc MSWEP_GHA_mar_05deg.nc
cdo remapcon2,../CHIRPS/grid_CHIRPS_05deg.txt MSWEP_GHA_apr.nc MSWEP_GHA_apr_05deg.nc
cdo remapcon2,../CHIRPS/grid_CHIRPS_05deg.txt MSWEP_GHA_may.nc MSWEP_GHA_may_05deg.nc
cdo remapcon2,../CHIRPS/grid_CHIRPS_05deg.txt MSWEP_GHA_oct.nc MSWEP_GHA_oct_05deg.nc
cdo remapcon2,../CHIRPS/grid_CHIRPS_05deg.txt MSWEP_GHA_nov.nc MSWEP_GHA_nov_05deg.nc
cdo remapcon2,../CHIRPS/grid_CHIRPS_05deg.txt MSWEP_GHA_dec.nc MSWEP_GHA_dec_05deg.nc
cdo remapcon2,../CHIRPS/grid_CHIRPS_05deg.txt MSWEP_GHA_MAM.nc MSWEP_GHA_MAM_05deg.nc
cdo remapcon2,../CHIRPS/grid_CHIRPS_05deg.txt MSWEP_GHA_OND.nc MSWEP_GHA_OND_05deg.nc

cdo ifthen ../CHIRPS/CHIRPS_monthly_OND_GRACE_19812014.nc MSWEP_GHA_mar_05deg.nc MSWEP_GHA_mar_05deg_lsm.nc
cdo ifthen ../CHIRPS/CHIRPS_monthly_OND_GRACE_19812014.nc MSWEP_GHA_apr_05deg.nc MSWEP_GHA_apr_05deg_lsm.nc
cdo ifthen ../CHIRPS/CHIRPS_monthly_OND_GRACE_19812014.nc MSWEP_GHA_may_05deg.nc MSWEP_GHA_may_05deg_lsm.nc
cdo ifthen ../CHIRPS/CHIRPS_monthly_OND_GRACE_19812014.nc MSWEP_GHA_oct_05deg.nc MSWEP_GHA_oct_05deg_lsm.nc
cdo ifthen ../CHIRPS/CHIRPS_monthly_OND_GRACE_19812014.nc MSWEP_GHA_nov_05deg.nc MSWEP_GHA_nov_05deg_lsm.nc
cdo ifthen ../CHIRPS/CHIRPS_monthly_OND_GRACE_19812014.nc MSWEP_GHA_dec_05deg.nc MSWEP_GHA_dec_05deg_lsm.nc
cdo ifthen ../CHIRPS/CHIRPS_monthly_OND_GRACE_19812014.nc MSWEP_GHA_MAM_05deg.nc MSWEP_GHA_MAM_05deg_lsm.nc
cdo ifthen ../CHIRPS/CHIRPS_monthly_OND_GRACE_19812014.nc MSWEP_GHA_OND_05deg.nc MSWEP_GHA_OND_05deg_lsm.nc

