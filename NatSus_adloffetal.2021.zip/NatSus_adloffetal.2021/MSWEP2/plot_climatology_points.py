#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

from netCDF4 import Dataset
import numpy as np
import csv
import itertools
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import matplotlib.patches as patches
from sklearn.linear_model import TheilSenRegressor
from sklearn.metrics import r2_score
import scipy
import mkt


### Read in nc-files and produce csv ###

months = np.arange(0,12)
#percentiles = ['0','u50','50','90','95','99']
#percentiles = ['0','99100']
percentile = '0'
years = np.arange(1979,2020)
n_years = np.arange(1,len(years)+1)
points = ['A','B','C','D']

#e = open('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_meanprec_bimodal_OND.csv','w')
#entry = '"Rain rate percentile [%]","annual rainfall [mm]"'
#e.write("%s\n" % entry)


trends = [[],[],[],[]]
trends_CHIRPS = [[],[],[],[]]
for point in range(len(points)):
	read_file = 'MSWEP_GHA_climatology_'+points[point]+'.nc'
	data = Dataset(read_file, 'r')
	#print data.variables
	trends[point] = data.variables['precipitation'][:,0,0] #lat,lon	
	
	read_file = '../CHIRPS/CHIRPS_climatology_'+points[point]+'.nc'
	data = Dataset(read_file, 'r')
	#print data.variables
	trends_CHIRPS[point] = data.variables['precip'][:,0,0] #lat,lon	
			

fig = plt.figure()
ax = fig.add_subplot(111)
#plt.grid()
colors = ('midnightblue','firebrick','peru','gray')
markers = ['s','D','^','o']
for point in range(len(points)):
	p4 = ax.scatter(months,trends[point], facecolor=colors[point],marker=markers[point], linewidth=2)
	p5, = ax.plot(months,trends[point], color=colors[point],alpha=0.5)
	p5, = ax.plot(months,trends_CHIRPS[point], color=colors[point],alpha=0.5,linestyle=':')
#	ax.legend([patches.Rectangle((0,0),2,0.05,linewidth=1,facecolor='steelblue',edgecolor='black'),mlines.Line2D([], [], color='midnightblue',marker='x',markersize=5),p6,p7], ['distribution of local\nrain totals above 95th %ile','spatial mean','linear approximation \n slope = '+str(round(a_ext,2))+' mm/yr','linear approximation 2002-2016\n slope = '+str(round(a_ext_grace,2))+' mm/yr'],ncol=2, loc=2,bbox_to_anchor=(-0.05,1.28),fontsize=10)
plt.xticks(rotation=45,fontsize=8)
plt.xticks([0,1,2,3,4,5,6,7,8,9,10,11],['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])
ax.set_ylim([0,510])
ax.set_ylabel('Precipitation (mm)')
plt.subplots_adjust(top=0.8)
#plt.savefig(months[month]+'_'+percentile+'pct_points_log.pdf')
plt.show()
	
