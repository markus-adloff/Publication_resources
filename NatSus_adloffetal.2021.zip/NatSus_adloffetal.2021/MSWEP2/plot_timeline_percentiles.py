#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from matplotlib import cm
import numpy as np
import csv
import seaborn as sns
from netCDF4 import Dataset
import matplotlib.patches as patches
from sklearn.linear_model import TheilSenRegressor
import scipy


### Read in csv files ###
infile='dataset_raintotals_MAM_0_newbimodal.csv'
tot_Data=pd.read_csv(infile)
tot_Data.head(0)
tot_years = []
tot_prec = []
with open(infile) as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
	if not row[0] == 'Year':
		tot_years.append(row[0])
		tot_prec.append(row[1])

infile='dataset_raintotals_MAM_99_newbimodal.csv'
Data=pd.read_csv(infile)
Data.head(0)
years = []
prec = []
with open(infile) as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')
    for row in csv_reader:
	if not row[0] == 'Year':
		years.append(row[0])
		prec.append(row[1])

### Plot PDFs ###

def plot_seaborn():

	fig = plt.figure()

	sns.set_style("whitegrid")
	ax1 = sns.boxplot(x="Year", y="Precipitation (mm)", data=Data, showfliers=False, palette="Blues_r")
	#ax = sns.swarmplot(x="Rain rate percentile (%)", y="Covariance", data=Data,size=0.5,linewidth=1)
	ax1.set_ylim([0,800])
	labels = [item.get_text() for item in ax1.get_xticklabels()]
	plt.locator_params(axis='x', nbins=12)
	labels_new = [labels[i] for i in range(0,len(labels),3)]
	ax1.set_xticklabels(np.asarray(labels_new))
	plt.xlabel("Year", fontsize=15)
	plt.ylabel("Precipitation (mm)", fontsize=15)

	plt.show()

def plot_trends_test():

	means = Data.groupby('Year').mean()
	years = Data.drop_duplicates(subset='Year')
	print len(years['Year']),len(means)
	a,b = np.polyfit(years['Year'],means['Precipitation (mm)'],1)

	fig = plt.figure()
	ax = fig.add_subplot(111)
	p1 = ax.scatter(years['Year'],means['Precipitation (mm)'], color='limegreen', linewidth=3)
	p2 = ax.plot(years['Year'],b+a*np.asarray(years['Year']),color='black')
	ax.set_ylim([0,800])
	plt.show()

def plot_trends_MAM():

	month='MAM'
	time = np.arange(1979,2020)
	read_file='MSWEP_above_0pct_'+str(month)+'_newbimodal_africa_fldmean.nc'
	data = Dataset(read_file, 'r')
	#print data.variables
	all_prec = data.variables['precipitation'][:,0,0] #time

	read_file='MSWEP_above_95pct_'+str(month)+'_newbimodal_africa_fldmean.nc'
	data = Dataset(read_file, 'r')
	ext_prec = data.variables['precipitation'][:,0,0] #time

	a,b = np.polyfit(time,all_prec,1)
	a_ext,b_ext = np.polyfit(time,ext_prec,1)
	print a, a_ext
	
	a_grace,b_grace = np.polyfit(time[23:36],all_prec[23:36],1)
	a_ext_grace,b_ext_grace = np.polyfit(time[23:36],ext_prec[23:36],1)
	print a_grace, a_ext_grace

	fig = plt.figure()
	ax = fig.add_subplot(111)
	plt.grid()
	p1 = ax.scatter(time,all_prec, color='midnightblue',alpha=0.5,marker='x', linewidth=2)
	p1, = ax.plot(time,all_prec, color='midnightblue',alpha=0.5)
	p2, = ax.plot(time,b+a*np.asarray(time),color='black',alpha=0.5)
	p3, = ax.plot(time[23:36],b_grace+a_grace*np.asarray(time[23:36]),color='firebrick',alpha=0.5)
	p4 = ax.scatter(time,ext_prec, color='midnightblue',marker='x', linewidth=2)
	p5, = ax.plot(time,ext_prec, color='midnightblue')
	p6, = ax.plot(time,b_ext+a_ext*np.asarray(time),color='black')
	p7, = ax.plot(time[23:36],b_ext_grace+a_ext_grace*np.asarray(time[23:36]),color='firebrick')
#	ax.set_ylim([0,800])
	ax.legend([mlines.Line2D([], [], color='midnightblue',alpha=0.5,marker='x',markersize=5),p2,p3,mlines.Line2D([], [], color='midnightblue',marker='x',markersize=5),p6,p7], ['total rainfall','linear approximation \n slope = '+str(round(a,2))+' mm/yr','linear approximation 2002-2014\n slope = '+str(round(a_grace,2))+' mm/yr','rain above 95th %ile','linear approximation \n slope = '+str(round(a_ext,2))+' mm/yr','linear approximation 2002-2014\n slope = '+str(round(a_ext_grace,2))+' mm/yr'],ncol=2, loc=2,bbox_to_anchor=(-0.1,1.35),fontsize=10)
	plt.ylabel("Precipitation (mm)", fontsize=15)
	plt.xlabel("Year", fontsize=15)
	plt.subplots_adjust(top=0.78)
	plt.show()
	
def plot_trends_OND():

	month='OND'
	time = np.arange(1978,2020)
	read_file='MSWEP_above_0pct_'+str(month)+'_newbimodal_africa_fldmean.nc'
	data = Dataset(read_file, 'r')
	#print data.variables
	all_prec = data.variables['precipitation'][:,0,0] #time

	read_file='MSWEP_above_95pct_'+str(month)+'_newbimodal_africa_fldmean.nc'
	data = Dataset(read_file, 'r')
	ext_prec = data.variables['precipitation'][:,0,0] #time

	a,b = np.polyfit(time[1:],all_prec[1:],1)
	a_ext,b_ext = np.polyfit(time[1:],ext_prec[1:],1)
	print a, a_ext
	
	a_grace,b_grace = np.polyfit(time[24:37],all_prec[24:37],1)
	a_ext_grace,b_ext_grace = np.polyfit(time[24:37],ext_prec[24:37],1)
	print a_grace, a_ext_grace

	fig = plt.figure()
	ax = fig.add_subplot(111)
	plt.grid()
	p1 = ax.scatter(time,all_prec, color='midnightblue',alpha=0.5,marker='x', linewidth=2)
	p1, = ax.plot(time,all_prec, color='midnightblue',alpha=0.5)
	p2, = ax.plot(time[1:],b+a*np.asarray(time[1:]),color='black',alpha=0.5)
	p3, = ax.plot(time[24:37],b_grace+a_grace*np.asarray(time[24:37]),color='firebrick',alpha=0.5)
	p4 = ax.scatter(time,ext_prec, color='midnightblue',marker='x', linewidth=2)
	p5, = ax.plot(time,ext_prec, color='midnightblue')
	p6, = ax.plot(time[1:],b_ext+a_ext*np.asarray(time[1:]),color='black')
	p7, = ax.plot(time[24:37],b_ext_grace+a_ext_grace*np.asarray(time[24:37]),color='firebrick')
#	ax.set_ylim([0,800])
	ax.legend([mlines.Line2D([], [], color='midnightblue',alpha=0.5,marker='x',markersize=5),p2,p3,mlines.Line2D([], [], color='midnightblue',marker='x',markersize=5),p6,p7], ['total rainfall','linear approximation \n slope = '+str(round(a,2))+' mm/yr','linear approximation 2002-2014\n slope = '+str(round(a_grace,2))+' mm/yr','rain above 95th %ile','linear approximation \n slope = '+str(round(a_ext,2))+' mm/yr','linear approximation 2002-2014\n slope = '+str(round(a_ext_grace,2))+' mm/yr'],ncol=2, loc=2,bbox_to_anchor=(-0.1,1.35),fontsize=10)
	plt.ylabel("Precipitation (mm)", fontsize=15)
	plt.xlabel("Year", fontsize=15)
	plt.subplots_adjust(top=0.78)
	plt.show()

def plot_totals_and_trends():

	fig = plt.figure()
	sns.set_style("whitegrid")
#
	ax = sns.boxplot(x="Year", y="Precipitation (mm)", data=tot_Data, showfliers=False, color="whitesmoke",zorder=0)
	#ax = sns.boxplot(x="Year", y="Precipitation (mm)", data=Data, showfliers=False, color="steelblue")
	labels = [item.get_text() for item in ax.get_xticklabels()]
	plt.locator_params(axis='x', nbins=12)
	labels_new = [labels[i] for i in range(0,len(labels),3)]
	ax.set_xticklabels(np.asarray(labels_new))
	plt.ylabel("Precipitation (mm)", fontsize=15)
	plt.xlabel("Year", fontsize=15)

	ax2 = ax.twinx()
#	p1 = ax2.scatter(time,all_prec, color='limegreen', linewidth=3)
#	p2 = ax2.plot(time,b+a*np.asarray(time),color='black')
#	p3 = ax2.scatter(time,ext_prec, color='slategray', linewidth=3)
#	p4, = ax2.plot(time,b+a*np.asarray(time),color='black')

	#p4, = ax2.plot(time,predict_y,color='black')

#	ax2.legend([p3,p4,patches.Rectangle((0,0),2,0.05,linewidth=1,facecolor='gainsboro',edgecolor='black')], ['linear approximation \n slope = 2.6 mm/yr','distribution of \n local rainfall totals'], loc=2,fontsize=10)
#	ax2.legend([p4,patches.Rectangle((0,0),2,0.05,linewidth=1,facecolor='gainsboro',edgecolor='black')], ['linear approximation \n slope = '+str(round(a,2))+' mm/yr, R$^2$ = '+str(round(score,2)),'distribution of \n local rainfall totals'], loc=2,fontsize=10)

#	ax2.legend([p4,patches.Rectangle((0,0),2,0.05,linewidth=1,facecolor='gainsboro',edgecolor='gray'),patches.Rectangle((0,0),2,0.05,linewidth=1,facecolor='steelblue',edgecolor='black')], ['linear approximation \n slope = '+str(round(a,2))+' mm/yr','distribution of \n local total rainfall','distribution of \n local extreme rainfall'], loc=2,fontsize=10)
	ax.set_ylim([0,400])
	ax2.set_ylim([0,400])
	plt.setp(ax2.yaxis.get_major_ticks(), visible=False)
	plt.setp(ax2.yaxis.get_minor_ticks(), visible=False)

	plt.show()
	#plt.savefig(month+'_timeseries_extremes.pdf')

#plot_seaborn()
#plot_totals_and_trends()
plot_trends_OND()
