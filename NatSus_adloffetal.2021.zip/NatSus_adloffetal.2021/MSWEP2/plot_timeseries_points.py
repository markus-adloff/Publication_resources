#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

from netCDF4 import Dataset
import numpy as np
import csv
import itertools
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import matplotlib.patches as patches
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)
from sklearn.linear_model import TheilSenRegressor
import scipy
import mkt


### Read in nc-files and produce csv ###

months = ['OND','MAM']
percentiles = ['99',]
years = np.arange(1979,2020)
n_years = np.arange(len(years))

points = ['A3','B3','C3','D3']
markers = ['s','D','^','o']
colors = ['midnightblue','firebrick','peru','gray']

for month in range(len(months)):
	print month
	for percentile in range(len(percentiles)):

		fig = plt.figure()
		ax = fig.add_subplot(111)
		#plt.grid()

		for point in range(len(points)):
			
			read_file='MSWEP2_above_'+percentiles[percentile]+'pct_'+points[point]+'_'+months[month]+'_nan.nc'
			#if percentiles[percentile] == '0':
			#	read_file='MSWEP2_'+points[point]+'_'+months[month]+'_3.nc'
			data = Dataset(read_file, 'r')
			ext_prec = data.variables['precipitation'][:,0,0] #time

			if month == 'OND':
				offset = 0
			else:
				offset = 0

			idx = np.isfinite(ext_prec[offset:])
			a_ext,b_ext = np.polyfit([n_years[i] for i in range(len(n_years)) if idx[i]],[ext_prec[i+offset] for i in range(len(ext_prec[offset:])) if idx[i]],1)
			idx = np.isfinite(ext_prec[23+offset:38+offset])
			a_ext_grace,b_ext_grace = np.polyfit([n_years[i] for i in range(23,38) if idx[i-23]],[ext_prec[i+offset] for i in range(23,38) if idx[i-23]],1)
			print a_ext, a_ext_grace
			
			#calculate significance
			idx = np.isfinite(ext_prec[offset:])
			x,a,b,p = mkt.test(np.asarray([n_years[i] for i in range(len(n_years)) if idx[i]]),np.asarray([ext_prec[i+offset] for i in range(len(ext_prec[offset:])) if idx[i]]),0.001,0.95,'upordown')
			idx = np.isfinite(ext_prec[23+offset:38+offset])
			x_grace,a_grace,b_grace,p_grace = mkt.test(np.asarray([n_years[i] for i in range(23,38) if idx[i-23]]),np.asarray([ext_prec[i+offset] for i in range(23,38) if idx[i-23]]),0.001,0.95,'upordown')
			idx = np.isfinite(ext_prec[offset:len(ext_prec)-3])
			x_test,a_test,b_test,p_test = mkt.test(np.asarray([n_years[i] for i in range(len(ext_prec)-3) if idx[i+offset]]),np.asarray([ext_prec[i+offset] for i in range(len(ext_prec)-3) if idx[i]]),0.001,0.95,'upordown')
			print a,p,'      ',a_test,p_test


			p4 = ax.scatter(years[offset:],ext_prec[offset:], color=colors[point],marker=markers[point], s=10)
			p5, = ax.plot(years[offset:],ext_prec[offset:], color=colors[point],linewidth=0.3)
			p6, = ax.plot(years[offset:],b_ext+a_ext*n_years[offset:], color=colors[point])


		plt.xticks(rotation=45,fontsize=8)
		ax.xaxis.set_minor_locator(MultipleLocator(1))
		ax.yaxis.grid()
		ax.set_ylim([0,600])
		ax.set_ylabel('Rainfall [mm]')
		#plt.subplots_adjust(top=0.8)
		plt.savefig(months[month]+'_'+percentiles[percentile]+'pct_points3.pdf')
		#plt.show()
	
