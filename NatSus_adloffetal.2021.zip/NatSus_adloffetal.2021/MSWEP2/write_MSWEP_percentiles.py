#! /home/ulfo/anaconda2/lib/python3.0
# -*- coding: utf-8 -*-

from netCDF4 import Dataset
import numpy as np
import csv
import itertools
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import matplotlib.patches as patches
from sklearn.linear_model import TheilSenRegressor
import scipy


### Read in nc-files and produce csv ###

months = ['OND','MAM']
#percentiles = ['0','u50','50','90','95','99']
#percentiles = ['0','99100']
percentiles = ['95','99']
years = np.arange(1979,2020)
n_years = np.arange(1,len(years)+1)

#e = open('/media/ulfo/KINGSTON/DREAD_Datasets/dataset_meanprec_bimodal_OND.csv','w')
#entry = '"Rain rate percentile [%]","annual rainfall [mm]"'
#e.write("%s\n" % entry)

for month in range(len(months)):
	print month
	for percentile in range(len(percentiles)):

#		e = open('dataset_raintotals_'+months[month]+'_'+percentiles[percentile]+'_newbimodal.csv','w')
#		entry = '"Year","Precipitation (mm)"'
#		e.write("%s\n" % entry)

		read_file='MSWEP_above_'+percentiles[percentile]+'pct_'+str(months[month])+'_newbimodal_africa_05deg.nc'

		data = Dataset(read_file, 'r')
		#print data.variables
		lons = data.variables['lon'][:]
		lats = data.variables['lat'][:]
		trends = data.variables['precipitation'][:,:,:] #lat,lon
		if months[month] == 'OND':
			offset = 1
		else:
			offset = 0

#		for lat in range(len(lats)): #lat, lon were inverted for R99 (for whatever reason...)
#			for lon in range(len(lons)):
#				for year in range(len(years)):
#					if np.isnan(trends[year+offset][lat][lon]) != True and trends[year+offset][lat][lon] > 0: # was >= for R99
#						entry = '"'+str(years[year])+'",'+str(trends[year+offset][lat][lon]) 
#						e.write("%s\n" % entry)
#
#		e.close()

		#print len(list(itertools.chain(*trends[0,:,:]))[0])

		all_data = []
		for year in range(len(years)):
			all_data.append(list(filter(lambda x: x >0, list(itertools.chain(*trends[year+offset,:,:])))))
#			all_data.append(list(filter(lambda x: x >=0, list(itertools.chain(*trends[year+offset,:,:])))))
			
		read_file='MSWEP_above_95pct_'+months[month]+'_newbimodal_africa_05deg_fldmean.nc'
		data = Dataset(read_file, 'r')
		ext_prec = data.variables['precipitation'][:,0,0] #time

		idx = np.isfinite(ext_prec[offset:])
		print idx, [ext_prec[i+offset] for i in range(len(ext_prec[offset:])) if idx[i]]
		a_ext,b_ext = np.polyfit([n_years[i] for i in range(len(n_years)) if idx[i]],[ext_prec[i+offset] for i in range(len(ext_prec[offset:])) if idx[i]],1)
		idx = np.isfinite(ext_prec[23+offset:38+offset])
		a_ext_grace,b_ext_grace = np.polyfit([n_years[i] for i in range(23,38) if idx[i-23]],[ext_prec[i+offset] for i in range(23,38) if idx[i-23]],1)

		fig = plt.figure()
		ax = fig.add_subplot(111)
		#plt.grid()
		p1 = ax.boxplot(all_data,showfliers=False,labels=years,whis=(0,100),patch_artist=True,boxprops={'facecolor':'steelblue'},zorder=-1)
		p4 = ax.scatter(n_years,ext_prec[offset:], color='midnightblue',marker='x', linewidth=2)
		p5, = ax.plot(n_years,ext_prec[offset:], color='midnightblue')
		p6, = ax.plot(n_years,b_ext+a_ext*np.asarray(n_years),color='black')
		p7, = ax.plot(n_years[23:38],b_ext_grace+a_ext_grace*np.asarray(n_years[23:38]),color='firebrick')
		ax.legend([patches.Rectangle((0,0),2,0.05,linewidth=1,facecolor='steelblue',edgecolor='black'),mlines.Line2D([], [], color='midnightblue',marker='x',markersize=5),p6,p7], ['distribution of local\nrain totals above 95th %ile','spatial mean','linear approximation \n slope = '+str(round(a_ext,2))+' mm/yr','linear approximation 2002-2016\n slope = '+str(round(a_ext_grace,2))+' mm/yr'],ncol=2, loc=2,bbox_to_anchor=(-0.05,1.28),fontsize=10)
		plt.xticks(rotation=45,fontsize=8)
		xticks0 = ax.xaxis.get_major_ticks()
		for i in range(0,len(xticks0),2):
			xticks0[i].set_visible(False)
		ax.set_ylim([0,600])
		ax.set_ylabel('Precipitation (mm)')
		plt.subplots_adjust(top=0.8)
		plt.savefig(months[month]+'_'+percentiles[percentile]+'pct_whis_05deg.pdf')
		#plt.show()
	
