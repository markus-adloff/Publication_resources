#!/bin/bash -l

#Create one file of annual precipitation

#cdo yearsum cru_ts4.01.1901.2016.pre.dat.nc cru_annual.nc

#cdo yearsum -selmon,3/6 cru_ts4.01.1901.2016.pre.dat.nc cru_longrains.nc
#cdo yearsum -selmon,9/11 cru_ts4.01.1901.2016.pre.dat.nc cru_shortrains.nc

#cdo -selmon,3 cru_ts4.01.1901.2016.pre.dat.nc cru_mar.nc
#cdo -selmon,4 cru_ts4.01.1901.2016.pre.dat.nc cru_apr.nc
#cdo -selmon,5 cru_ts4.01.1901.2016.pre.dat.nc cru_may.nc
#cdo -selmon,10 cru_ts4.01.1901.2016.pre.dat.nc cru_oct.nc
#cdo -selmon,11 cru_ts4.01.1901.2016.pre.dat.nc cru_nov.nc
#cdo -selmon,12 cru_ts4.01.1901.2016.pre.dat.nc cru_dec.nc

for mon in mar apr may oct nov dec MAM OND
do

cdo -fldstd -selyear,1983/2013 -sellonlatbox,33,54,-10,8 CRU_${mon}.nc cru_fldstd_${mon}.nc
#cdo -div cru_fldstd_${mon}.nc -fldmean -selyear,1983/2013 -sellonlatbox,33,54,-10,8 CRU_${mon}.nc cru_fldcv_seasonavg_${mon}.nc
#cdo regres cru_fldcv_seasonavg_${mon}.nc cru_b_fldcv_seasonavg_${mon}.nc

done
