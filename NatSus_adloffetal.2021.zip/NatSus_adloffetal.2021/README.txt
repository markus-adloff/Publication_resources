#README

# Scripts used to analyse data and produce figures for Adloff et al.: "Sustained water storage in Horn of Africa drylands dominated by seasonal rainfall extremes"
# Provided are scripts for the preparation and processing of each data set used in the study, as well as generic scripts that were used to combine information from different data sets and produce the figures in our manuscript

# Rainfall data

# For each data set, there is a prepare_*.sh script which has been used to select the region and period of study
# The script prepare_timeseries_obs.sh prepares timeseries data, which can then be exported to a csv file with write_timeseries.py and plotted with plot_timeseries.py. 
# write_dataset_csv_newbimodal.py creates a csv file that can be used to plot the distribution of rainfall changes, using plot_PDFs.py


# GRACE-derived data is processed and plotted with the scripts in the folder 'GRACE'

# Aridity index data is prepared and plotted with the scripts containing 'AI' in their name
