#### README Supplementary data to Adloff et al., 2024 ####

The simulation output for the step change experiments is provided
in the archive output.tar.gz. The archive contains one file per 
location and choice of sediment treatment (files containing results
of simulations without interactive sediments carry an additional 'C'
in their name). Each file contains the results of all step change
simulations for this location. The file names mean the following
scenarios discussed in the manuscript:

'remin' - step change in remineralisation rate,
'fw'- hosing in the North Atlantic
'caco' - reduction of PIC:POC in export production
'sowi' - weakening of winds over the Southern Ocean
'rad' - reduction of global insolation by 9 W/m2
'phos' -  additional input of nutrients

The simulation output for the simulations of full glacial cycles
is provided with the Manuscript Adloff et al., 2024, Clim. Past 
and can be downloaded here: https://doi.org/10.5281/zenodo.11385608
In this case, a netcdf file for each simulation contains the
variables plotted and discussed in the manuscript. The names of the
simulations correspond to those used in the manuscript Adloff et
al., 2024 Clim. Past

We also provide the Jupyter Notebook 'create_figures.ipynb' which
which contains routines to read in the simulation output and 
produce the figures shown in the main text of the manuscript. The
Notebook can be adjusted to further explore the simulation output.

For questions, please contact Markus Adloff (markus.adloff@bristol.ac.uk)
